"""runtime/wrapper — HIBM bot process wrapper and injection layer."""
from runtime.wrapper import injector

__all__ = ["injector"]
