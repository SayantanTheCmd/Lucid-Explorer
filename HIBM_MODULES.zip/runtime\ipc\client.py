# Bot-side IPC client lives in runtime/wrapper/_hibm_wrapper.py
