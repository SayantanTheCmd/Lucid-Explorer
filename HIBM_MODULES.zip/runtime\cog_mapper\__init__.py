"""runtime/cog_mapper/__init__.py"""
