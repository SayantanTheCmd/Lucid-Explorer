"""
runtime/ipc/server.py
HIBM-side TCP IPC server.

Listens on 127.0.0.1:0 (OS picks port). The assigned port is exposed
via the `port` property and must be passed to the bot subprocess as the
HIBM_IPC_PORT environment variable.

Accepts exactly one client (the bot process).
All I/O runs in a daemon thread — never blocks the main thread.
"""

import queue
import socket
import threading
from typing import Optional

from runtime.ipc.protocol import Msg, MsgType
from runtime.utils.logger  import get_logger

log = get_logger(__name__)

_BUF = 4096


class IPCServer:
    """Single-client IPC server. Thread-safe send / request API."""

    def __init__(self) -> None:
        self._server_sock: Optional[socket.socket] = None
        self._client_sock: Optional[socket.socket] = None
        self._port:  int = 0
        self._lock   = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._reply_queues: dict[str, queue.Queue] = {}
        self._running = False
        # Callbacks registered from outside (e.g. for READY event)
        self._event_handlers: dict[MsgType, list] = {}

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def start(self) -> int:
        """Bind, listen, start accept loop. Returns the assigned port."""
        self._server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_sock.bind(("127.0.0.1", 0))
        self._server_sock.listen(1)
        self._port    = self._server_sock.getsockname()[1]
        self._running = True
        self._thread  = threading.Thread(
            target=self._accept_loop, name="ipc-server", daemon=True
        )
        self._thread.start()
        log.info("[IPC] Server ready on 127.0.0.1:%d", self._port)
        return self._port

    def stop(self) -> None:
        self._running = False
        for s in (self._client_sock, self._server_sock):
            if s:
                try:
                    s.close()
                except Exception:
                    pass
        self._client_sock = None

    @property
    def port(self) -> int:
        return self._port

    @property
    def connected(self) -> bool:
        return self._client_sock is not None

    # ── Send / request ─────────────────────────────────────────────────────────

    def send(self, msg: Msg) -> bool:
        """Fire-and-forget. Returns True if the bytes were sent."""
        with self._lock:
            if not self._client_sock:
                return False
            try:
                self._client_sock.sendall(msg.encode())
                log.debug("[IPC] -> %s id=%s", msg.type, msg.id)
                return True
            except Exception as exc:
                log.warning("[IPC] Send failed: %s", exc)
                self._client_sock = None
                return False

    def request(self, msg: Msg, timeout: float = 10.0) -> Optional[Msg]:
        """Send msg and block until a reply with the same id arrives."""
        q: queue.Queue = queue.Queue()
        self._reply_queues[msg.id] = q
        try:
            if not self.send(msg):
                return None
            return q.get(timeout=timeout)
        except queue.Empty:
            log.warning("[IPC] Timeout waiting for reply to %s", msg.id)
            return None
        finally:
            self._reply_queues.pop(msg.id, None)

    def on(self, msg_type: MsgType, handler) -> None:
        """Register a callback for unsolicited bot events."""
        self._event_handlers.setdefault(msg_type, []).append(handler)

    # ── Internal ───────────────────────────────────────────────────────────────

    def _accept_loop(self) -> None:
        self._server_sock.settimeout(1.0)
        while self._running:
            try:
                client, addr = self._server_sock.accept()
                log.info("[IPC] Bot connected from %s", addr)
                self._client_sock = client
                self._recv_loop(client)
            except socket.timeout:
                continue
            except Exception as exc:
                if self._running:
                    log.debug("[IPC] Accept: %s", exc)

    def _recv_loop(self, client: socket.socket) -> None:
        buf = ""
        client.settimeout(1.0)
        while self._running:
            try:
                chunk = client.recv(_BUF).decode("utf-8", errors="replace")
                if not chunk:
                    log.info("[IPC] Bot disconnected")
                    self._client_sock = None
                    return
                buf += chunk
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    line = line.strip()
                    if line:
                        self._dispatch(line)
            except socket.timeout:
                continue
            except Exception as exc:
                if self._running:
                    log.warning("[IPC] Recv: %s", exc)
                self._client_sock = None
                return

    def _dispatch(self, line: str) -> None:
        try:
            msg = Msg.decode(line)
            log.debug("[IPC] <- %s id=%s data=%s", msg.type, msg.id, msg.data)
            # Route to waiting request() if any
            if msg.id in self._reply_queues:
                self._reply_queues[msg.id].put(msg)
                return
            # Fire registered event handlers
            for handler in self._event_handlers.get(msg.type, []):
                try:
                    handler(msg)
                except Exception as exc:
                    log.warning("[IPC] Handler error: %s", exc)
            # Built-in logging for common events
            self._builtin_log(msg)
        except Exception as exc:
            log.warning("[IPC] Bad message: %s — %r", exc, line)

    def _builtin_log(self, msg: Msg) -> None:
        if msg.type == MsgType.HEARTBEAT:
            log.debug("[IPC] Heartbeat from bot")
        elif msg.type == MsgType.READY:
            name   = msg.data.get("bot_name", "?")
            guilds = msg.data.get("guild_count", "?")
            log.info("[IPC] Bot ready: %s on %s guild(s)", name, guilds)
            print(f"\n  [IPC] Bot connected — {name} ({guilds} guild(s))", flush=True)
        elif msg.type == MsgType.COG_RELOADED:
            cog = msg.data.get("cog", "?")
            ok  = msg.data.get("ok", False)
            if ok:
                log.info("[IPC] Cog reloaded: %s", cog)
            else:
                log.warning("[IPC] Cog reload failed: %s — %s", cog, msg.data.get("error"))
        elif msg.type == MsgType.PONG:
            log.debug("[IPC] Pong received")
