"""
unloader/downloader.py
════════════════════════════════════════════════════════════════
HIBM Package Bundle Downloader

Downloads preinstalled.zip from GitHub on first boot (or after a
clean shutdown deleted the previous copy).

Source repo : https://github.com/SayantanTheCmd/Lucid-Explorer
File        : preinstalled.zip  (22.2 MB)

Uses ONLY Python stdlib (urllib) — no third-party packages required,
since those packages haven't been extracted yet when this runs.
════════════════════════════════════════════════════════════════
"""

import os
import sys
import threading
import time
import urllib.request
import urllib.error
from typing import Optional

# ── Download source ───────────────────────────────────────────────────────────
_REPO_OWNER   = "SayantanTheCmd"
_REPO_NAME    = "Lucid-Explorer"
_FILE_NAME    = "preinstalled.zip"
_BRANCH       = "main"

# Primary: raw.githubusercontent.com direct binary download
_RAW_URL = (
    f"https://raw.githubusercontent.com/"
    f"{_REPO_OWNER}/{_REPO_NAME}/{_BRANCH}/{_FILE_NAME}"
)

# Fallback: GitHub API download_url (same content, different CDN path)
_API_URL = (
    f"https://api.github.com/repos/{_REPO_OWNER}/{_REPO_NAME}"
    f"/contents/{_FILE_NAME}"
)

_UA = (
    "Mozilla/5.0 (compatible; HIBM-Downloader/1.0; "
    "+https://github.com/SayantanTheCmd/Lucid-Explorer)"
)

# ── Public API ─────────────────────────────────────────────────────────────────

def download(dest_path: str) -> bool:
    """
    Download preinstalled.zip from GitHub to dest_path.

    Args:
        dest_path: Absolute path where the zip should be saved.

    Returns:
        True on success, False on failure.
    """
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    partial = dest_path + ".part"

    print()

    # ── Try primary raw URL ───────────────────────────────────────────────────
    ok = _stream_download(_RAW_URL, partial, dest_path)
    if ok:
        return True

    # ── Fallback: resolve download URL via GitHub API ─────────────────────────
    _info("Primary URL failed — resolving via GitHub API ...")
    api_url = _resolve_via_api()
    if api_url:
        # Clean up failed partial
        if os.path.exists(partial):
            os.remove(partial)
        ok = _stream_download(api_url, partial, dest_path)
        if ok:
            return True

    _err("All download attempts failed.")
    _err("Check your internet connection and try again.")
    return False


# ── Internal ──────────────────────────────────────────────────────────────────

def _stream_download(url: str, partial_path: str, final_path: str) -> bool:
    """
    Stream a URL to partial_path, then rename to final_path on success.
    Shows a live progress bar using carriage-return line updates.
    """
    req = urllib.request.Request(url, headers={"User-Agent": _UA})

    # Show a spinner IMMEDIATELY so the 1-3s DNS+TCP delay doesn't look frozen.
    _stop_spinner = threading.Event()
    def _spin():
        chars = "-\\|/"
        i = 0
        while not _stop_spinner.is_set():
            sys.stdout.write(f"\r  [{chars[i % 4]}]  Connecting to GitHub CDN ...")
            sys.stdout.flush()
            i += 1
            time.sleep(0.08)
    spin_t = threading.Thread(target=_spin, daemon=True)
    spin_t.start()

    try:
        response = urllib.request.urlopen(req, timeout=30)
    except urllib.error.HTTPError as exc:
        _stop_spinner.set()
        sys.stdout.write("\r" + " " * 50 + "\r")
        _err(f"HTTP {exc.code}: {exc.reason}  ({url})")
        return False
    except urllib.error.URLError as exc:
        _stop_spinner.set()
        sys.stdout.write("\r" + " " * 50 + "\r")
        _err(f"Connection error: {exc.reason}")
        return False
    except Exception as exc:
        _stop_spinner.set()
        sys.stdout.write("\r" + " " * 50 + "\r")
        _err(f"Request failed: {exc}")
        return False
    finally:
        _stop_spinner.set()

    sys.stdout.write("\r" + " " * 50 + "\r")  # clear spinner
    sys.stdout.flush()

    total_bytes = int(response.headers.get("Content-Length", 0))
    downloaded  = 0
    chunk_size  = 65536   # 64 KB
    start_time  = time.monotonic()

    try:
        with open(partial_path, "wb") as f:
            while True:
                chunk = response.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                _print_progress(downloaded, total_bytes, start_time)
    except OSError as exc:
        print()
        _err(f"Write error: {exc}")
        return False
    except KeyboardInterrupt:
        print()
        _warn("Download interrupted by user.")
        return False

    if downloaded == 0:
        sys.stdout.write("\n")
        _err("Download produced an empty file.")
        return False

    if total_bytes > 0 and downloaded < total_bytes:
        sys.stdout.write("\n")
        _err(f"Incomplete: received {downloaded:,} / {total_bytes:,} bytes.")
        return False

    # Verify zip magic bytes PK (0x50 0x4B)
    try:
        with open(partial_path, "rb") as f:
            if f.read(2) != b"PK":
                _err("Downloaded file is not a valid ZIP archive.")
                _err("(Got HTML or an error page instead of the zip.)")
                os.remove(partial_path)
                return False
    except OSError:
        pass

    # Commit: rename partial → final
    if os.path.exists(final_path):
        os.remove(final_path)
    os.rename(partial_path, final_path)

    size_mb = downloaded / (1024 * 1024)
    _ok(f"Download complete — {size_mb:.1f} MB")
    return True


def _resolve_via_api() -> Optional[str]:
    """
    Call the GitHub Contents API to get the direct download_url for the zip.
    Returns the URL string, or None on failure.
    """
    import json
    req = urllib.request.Request(
        _API_URL,
        headers={
            "User-Agent": _UA,
            "Accept": "application/vnd.github+json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("download_url")
    except Exception as exc:
        _err(f"GitHub API error: {exc}")
        return None


def _print_progress(downloaded: int, total: int, start_time: float) -> None:
    """Render a live ██░░ progress bar with speed and ETA using \\r."""
    elapsed  = max(time.monotonic() - start_time, 0.001)
    speed    = downloaded / elapsed
    dl_mb    = downloaded / (1024 * 1024)
    spd_str  = _fmt_speed(speed)

    if total > 0:
        pct      = downloaded / total * 100
        total_mb = total / (1024 * 1024)
        bar_len  = 28
        filled   = int(bar_len * downloaded / total)
        bar      = "\u2588" * filled + "\u2591" * (bar_len - filled)
        eta_sec  = max((total - downloaded) / max(speed, 1), 0)
        line = (
            f"\033[32m│\033[0m  [{bar}] {pct:5.1f}%  "
            f"{dl_mb:.1f} / {total_mb:.1f} MB  "
            f"{spd_str}  ETA {_fmt_time(eta_sec)}"
        )
    else:
        spinner  = r"-\|/"[int(elapsed * 4) % 4]
        line = f"\033[32m│\033[0m  [{spinner}] {dl_mb:.1f} MB downloaded  {spd_str}"

    sys.stdout.write(f"\r  {line:<80}")
    sys.stdout.flush()


def _fmt_speed(bps: float) -> str:
    if bps >= 1_048_576:
        return f"{bps / 1_048_576:.1f} MB/s"
    if bps >= 1024:
        return f"{bps / 1024:.0f} KB/s"
    return f"{bps:.0f} B/s"


def _fmt_time(sec: float) -> str:
    if sec >= 3600:
        return f"{int(sec // 3600)}h {int((sec % 3600) // 60)}m"
    if sec >= 60:
        return f"{int(sec // 60)}m {int(sec % 60)}s"
    return f"{int(sec)}s"


# ── Minimal print helpers (zero runtime.utils dependency) ─────────────────────
def _ok(msg: str)   -> None: 
    sys.stdout.write(f"\r  \033[32m│\033[0m  \033[92m\033[1m✔\033[0m  {msg:<80}\n")
    sys.stdout.flush()
def _info(msg: str) -> None: print(f"  \033[32m│\033[0m  \033[96m\033[1m◈\033[0m  {msg}")
def _warn(msg: str) -> None: print(f"  \033[32m│\033[0m  \033[93m\033[1m⚠\033[0m  {msg}")
def _err(msg: str)  -> None: print(f"  \033[32m│\033[0m  \033[91m\033[1m✖\033[0m  {msg}")
