"""
runtime/decision_engine/strategies.py
Pure decision logic — no I/O, no side effects.

Given a DiffResult, return the minimum-disruption Action.

Severity ladder (lowest to highest):
    PULL_ONLY < HOT_RELOAD < HOT_RESTART

When multiple categories are present, the highest severity wins.
"""

from enum import Enum

from runtime.decision_engine.analyzer import DiffResult, ChangeKind


class Action(str, Enum):
    NONE        = "none"         # nothing to do
    PULL_ONLY   = "pull_only"    # git pull; bot keeps running untouched
    HOT_RELOAD  = "hot_reload"   # git pull + reload only the changed cog(s)
    HOT_RESTART = "hot_restart"  # git pull + [pip install] + stop + start


def decide(diff: DiffResult) -> Action:
    """
    Map a DiffResult to the minimum-disruption Action.

    Decision rules (first match wins, in descending severity):

    → HOT_RESTART if ANY of:
        • main.py changed
        • requirements.txt changed
        • a cog was ADDED (needs bot.load_extension, not just reload)
        • a cog was DELETED or RENAMED
        • a .py file outside cogs/ changed (unknown side effects)

    → HOT_RELOAD if:
        • only EXISTING cogs were modified (no adds/deletes/main/req changes)

    → PULL_ONLY if:
        • only static / non-code files changed (.env, .txt, .json, .md …)

    → NONE if:
        • the diff is empty
    """
    if not diff.changes:
        return Action.NONE

    # ── Highest severity checks ───────────────────────────────────────────────
    if diff.main_changed:
        return Action.HOT_RESTART

    if diff.requirements_changed:
        return Action.HOT_RESTART

    if diff.added_cogs:
        return Action.HOT_RESTART

    if diff.deleted_cogs:          # includes renames
        return Action.HOT_RESTART

    # Any .py file outside cogs/ — unknown impact, restart to be safe
    if any(c.kind == ChangeKind.OTHER_CODE for c in diff.changes):
        return Action.HOT_RESTART

    # ── Mid severity ──────────────────────────────────────────────────────────
    if diff.modified_cogs:
        return Action.HOT_RELOAD

    # ── Lowest severity ───────────────────────────────────────────────────────
    if diff.has_static_only:
        return Action.PULL_ONLY

    # Fallback (should rarely reach here)
    return Action.PULL_ONLY


def describe(action: Action, diff: DiffResult) -> str:
    """Return a human-readable explanation of why this action was chosen."""
    reasons = []

    if action == Action.NONE:
        return "No changes detected."

    if action == Action.HOT_RESTART:
        if diff.main_changed:
            reasons.append("main.py was modified")
        if diff.requirements_changed:
            reasons.append("requirements.txt changed")
        if diff.added_cogs:
            reasons.append(f"{len(diff.added_cogs)} new cog(s) added")
        if diff.deleted_cogs:
            reasons.append(f"{len(diff.deleted_cogs)} cog(s) removed/renamed")
        if any(c.kind == ChangeKind.OTHER_CODE for c in diff.changes):
            reasons.append("helper .py file(s) changed")
        return "Hot Restart — " + ", ".join(reasons)

    if action == Action.HOT_RELOAD:
        cog_list = ", ".join(diff.modified_cogs)
        return f"Hot Reload — cog(s) modified: {cog_list}"

    if action == Action.PULL_ONLY:
        return "Pull Only — only static/non-code files changed, bot keeps running"

    return str(action)
