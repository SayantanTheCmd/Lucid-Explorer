"""
runtime/utils/helpers.py
Miscellaneous utility functions.
"""

import re
import subprocess
import sys
from typing import Optional


def is_git_installed() -> bool:
    """Return True if `git` is available on PATH."""
    try:
        result = subprocess.run(
            ["git", "--version"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def python_version_ok(min_major: int = 3, min_minor: int = 10) -> bool:
    """Return True if the running Python is >= min_major.min_minor."""
    return sys.version_info >= (min_major, min_minor)


def inject_token_into_url(url: str, token: str) -> str:
    """
    Embed a personal access token into an HTTPS GitHub/GitLab URL.

    https://github.com/user/repo.git
    → https://<token>@github.com/user/repo.git
    """
    url = url.strip()
    if url.startswith("https://"):
        return url.replace("https://", f"https://{token}@", 1)
    # SSH URLs cannot embed tokens — return as-is and let git handle auth
    return url


def normalise_url(url: str) -> str:
    """Strip whitespace and trailing slashes from a URL."""
    return url.strip().rstrip("/")


def format_bytes(num_bytes: int) -> str:
    """Human-readable byte size string."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} PB"


def slugify(text: str) -> str:
    """Convert text to a lowercase slug safe for filenames."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_-]+", "-", text)
    return text.strip("-")


def run_subprocess(
    cmd: list[str],
    cwd: Optional[str] = None,
    timeout: Optional[int] = None,
    capture: bool = True,
) -> tuple[int, str, str]:
    """
    Run a subprocess and return (returncode, stdout, stderr).
    If capture=False, output goes directly to the terminal.
    """
    kwargs = dict(cwd=cwd, timeout=timeout)
    if capture:
        kwargs["stdout"] = subprocess.PIPE
        kwargs["stderr"] = subprocess.PIPE
        kwargs["text"] = True
    try:
        proc = subprocess.run(cmd, **kwargs)
        if capture:
            return proc.returncode, proc.stdout or "", proc.stderr or ""
        return proc.returncode, "", ""
    except subprocess.TimeoutExpired:
        return -1, "", "Process timed out"
    except FileNotFoundError:
        return -1, "", f"Command not found: {cmd[0]}"
    except Exception as exc:
        return -1, "", str(exc)


def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences from a string."""
    ansi_escape = re.compile(r"\033\[[0-9;]*m")
    return ansi_escape.sub("", text)
