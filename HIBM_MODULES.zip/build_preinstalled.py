"""
build_preinstalled.py
════════════════════════════════════════════════════════════════
HIBM Pre-installed Package Builder

Run this ONCE (or whenever you want to update the bundle) to create
unloader/preinstalled.zip, which contains all pre-compiled packages
ready to be extracted by unloader/unloader.py at bot startup.

Usage:
    python build_preinstalled.py

What it does:
  1. pip install --target=cache/temp/pkg_build/ <all packages>
  2. Zip everything in that directory → unloader/preinstalled.zip
  3. Clean up the temp directory

Platform note:
  uvloop is skipped on Windows (not compatible).
  Build this on the SAME OS as your production server for best results.
  If deploying on Linux/Pterodactyl, build on Linux.
════════════════════════════════════════════════════════════════
"""

import os
import sys
import shutil
import platform
import subprocess
import zipfile
from pathlib import Path

# ── Paths ─────────────────────────────────────────────────────────────────────
_HERE        = Path(__file__).parent.resolve()
_BUILD_DIR   = _HERE / "cache" / "temp" / "pkg_build"
_OUTPUT_ZIP  = _HERE / "unloader" / "preinstalled.zip"
_STAMP_FILE  = _HERE / "cache" / "packages" / ".unloaded"

PACKAGES = [
    # -- Core Engine dependencies --
    "discord.py",
    "aiohttp",
    "aiosqlite",
    "python-dotenv",
    "orjson",
    "psutil",
    "watchdog",
    "GitPython",
    "PyYAML",
    "pydantic",
    "rich",
    "colorama",
    "cryptography",
    "tenacity",
    "apscheduler",
    "httpx",
    "aiocache",
    "typing_extensions",
    "packaging",
    
    # -- Bot-specific dependencies --
    "Quart",
    "jishaku",
    "yt-dlp",
    "PyNaCl",
    "gtts",
    "requests",
    "openai",
    "google-genai",
    "duckduckgo-search==6.3.6",
    "pillow",
    "chess",
    "pytz",
    
    # -- 9 Extra Popular Bot Packages --
    "numpy",
    "pandas",
    "beautifulsoup4",
    "lxml",
    "motor",
    "pymongo",
    "redis",
    "sqlalchemy",
    "asyncpg",
]

# Packages that are pure python but only distribute source (.tar.gz), breaking --only-binary
PURE_PYTHON_PACKAGES = [
    "langdetect",
    "davey",
]

# uvloop is Linux/macOS only
# We always include it now since we are targeting Linux
if "uvloop" not in PACKAGES:
    PACKAGES.append("uvloop")

# ── Helpers ───────────────────────────────────────────────────────────────────
_RESET = "\033[0m"
_G = "\033[32m\033[1m"   # Green bold
_C = "\033[36m\033[1m"   # Cyan bold
_Y = "\033[33m\033[1m"   # Yellow bold
_R = "\033[31m\033[1m"   # Red bold

def ok(msg):   print(f"  {_G}[OK]{_RESET}  {msg}")
def info(msg): print(f"  {_C}[>>]{_RESET}  {msg}")
def warn(msg): print(f"  {_Y}[!!]{_RESET}  {msg}")
def err(msg):  print(f"  {_R}[XX]{_RESET}  {msg}")
def header(msg): print(f"\n  -- {msg} {'-' * max(0, 50 - len(msg))}")


def main() -> None:
    print()
    print("  +==================================================+")
    print("  |      HIBM -- Pre-installed Package Builder      |")
    print("  +==================================================+")
    print()
    info(f"Target OS: Linux (x86_64)")
    info(f"Target Python: 3.13")
    info(f"Packages : {len(PACKAGES) + len(PURE_PYTHON_PACKAGES)}")
    info(f"Output   : {_OUTPUT_ZIP}")
    print()

    # -- Step 1: Prepare build directory ---------------------------------------
    header("Preparing Build Directory")
    if _BUILD_DIR.exists():
        info("Removing old build directory ...")
        shutil.rmtree(_BUILD_DIR)
    _BUILD_DIR.mkdir(parents=True, exist_ok=True)
    _OUTPUT_ZIP.parent.mkdir(parents=True, exist_ok=True)
    ok(f"Build directory ready: {_BUILD_DIR}")

    # -- Step 2: pip install --target (Binary Wheels) --------------------------
    header("Installing Binary Packages for Linux (Python 3.13)")
    info("Running pip install --target (this may take a while) ...")
    print()

    cmd_binary = [
        sys.executable, "-m", "pip", "install",
        "--target", str(_BUILD_DIR),
        "--upgrade",
        "--no-user",
        "--quiet",
        "--progress-bar", "on",
        
        # Cross-compile flags so Windows downloads Linux binaries!
        "--platform", "manylinux2014_x86_64",
        "--python-version", "3.13",
        "--only-binary=:all:",
        
        *PACKAGES,
    ]

    proc1 = subprocess.run(cmd_binary, text=True)

    if proc1.returncode != 0:
        err(f"pip install (binary) failed with exit code {proc1.returncode}")
        err("Check your internet connection or package names and retry.")
        sys.exit(1)

    ok("All binary packages installed into build directory.")

    # -- Step 2b: pip install --target (Pure Python) ---------------------------
    header("Installing Pure Python Packages")
    print()
    
    cmd_pure = [
        sys.executable, "-m", "pip", "install",
        "--target", str(_BUILD_DIR),
        "--upgrade",
        "--no-user",
        "--quiet",
        *PURE_PYTHON_PACKAGES,
    ]

    proc2 = subprocess.run(cmd_pure, text=True)
    if proc2.returncode != 0:
        err(f"pip install (pure python) failed with exit code {proc2.returncode}")
        sys.exit(1)

    ok("All pure python packages installed.")

    # -- Step 3: Count files ---------------------------------------------------
    all_files = list(_BUILD_DIR.rglob("*"))
    file_count = sum(1 for f in all_files if f.is_file())
    info(f"Total files to archive: {file_count:,}")

    # -- Step 4: Zip -----------------------------------------------------------
    header("Creating preinstalled.zip")
    info(f"Writing to: {_OUTPUT_ZIP}")

    if _OUTPUT_ZIP.exists():
        warn("Overwriting existing preinstalled.zip")
        _OUTPUT_ZIP.unlink()

    written = 0
    with zipfile.ZipFile(_OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for filepath in _BUILD_DIR.rglob("*"):
            if filepath.is_file():
                # MUST use forward slashes for Linux compatibility
                arcname = str(filepath.relative_to(_BUILD_DIR)).replace("\\", "/")
                zf.write(filepath, arcname)
                written += 1
                if written % 200 == 0:
                    info(f"  Archived {written:,}/{file_count:,} files ...")

    zip_size_mb = _OUTPUT_ZIP.stat().st_size / (1024 * 1024)
    ok(f"Created preinstalled.zip — {written:,} files, {zip_size_mb:.1f} MB")

    # -- Step 5: Clean build dir -----------------------------------------------
    header("Cleaning Up")
    shutil.rmtree(_BUILD_DIR)
    ok("Temporary build directory removed.")

    # -- Step 6: Invalidate cache stamp ----------------------------------------
    if _STAMP_FILE.exists():
        _STAMP_FILE.unlink()
        info("Cache stamp cleared — next startup will re-extract the new zip.")

    # -- Done ------------------------------------------------------------------
    print()
    print("  +==================================================+")
    print("  |              Build Complete!                     |")
    print("  +==================================================+")
    print()
    ok(f"preinstalled.zip is ready at:  {_OUTPUT_ZIP}")
    info("You can now run:  python Startall.py")
    print()


if __name__ == "__main__":
    main()
