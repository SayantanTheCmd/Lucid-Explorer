# IPC event constants are in runtime/ipc/protocol.py MsgType enum
