"""
runtime/utils/config.py
Load and persist the HIBM configuration from/to config/settings.json.

The config is a plain dict merged on top of the defaults at startup.
Any key not present in settings.json falls back to the value in defaults.py.
"""

import json
import os
from typing import Any

from runtime.constants.paths    import SETTINGS_FILE
from runtime.constants.defaults import (
    BASE_PACKAGES,
    PIP_BATCH_SIZE,
    PIP_TIMEOUT_SECONDS,
    PIP_UPGRADE_BASE,
    GIT_POLL_INTERVAL,
    BOT_RESTART_ON_CRASH,
    MAX_CRASH_RETRIES,
    LOG_LEVEL,
)
from runtime.utils.logger import get_logger

log = get_logger(__name__)

# ── Default config structure ──────────────────────────────────────────────────
_DEFAULTS: dict[str, Any] = {
    "base_packages"       : BASE_PACKAGES,
    "pip_batch_size"      : PIP_BATCH_SIZE,
    "pip_timeout_seconds" : PIP_TIMEOUT_SECONDS,
    "pip_upgrade_base"    : PIP_UPGRADE_BASE,
    "git_poll_interval"   : GIT_POLL_INTERVAL,
    "bot_restart_on_crash": BOT_RESTART_ON_CRASH,
    "max_crash_retries"   : MAX_CRASH_RETRIES,
    "log_level"           : LOG_LEVEL,
}

# ── In-memory singleton ───────────────────────────────────────────────────────
_config: dict[str, Any] = {}


def load() -> dict[str, Any]:
    """
    Load settings.json and merge with defaults.
    Missing keys fall back to default values.
    Returns the in-memory config dict.
    """
    global _config
    _config = dict(_DEFAULTS)  # Start from a fresh copy of defaults

    if os.path.isfile(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            _config.update(data)
            log.debug("Config loaded from %s", SETTINGS_FILE)
        except (json.JSONDecodeError, OSError) as exc:
            log.warning("Could not read settings.json (%s) — using defaults.", exc)
    else:
        log.debug("settings.json not found — using defaults.")
        save()  # Write defaults to disk for first-time users

    return _config


def save() -> None:
    """Persist the current in-memory config back to settings.json."""
    os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(_config, f, indent=2)
        log.debug("Config saved to %s", SETTINGS_FILE)
    except OSError as exc:
        log.error("Failed to save settings.json: %s", exc)


def get(key: str, default: Any = None) -> Any:
    """Get a config value by key."""
    return _config.get(key, default)


def set(key: str, value: Any) -> None:
    """Set a config value and persist immediately."""
    _config[key] = value
    save()


def all_settings() -> dict[str, Any]:
    """Return a copy of the full config dict."""
    return dict(_config)
