"""
runtime/ui/startup.py
Premium CLI interface for HIBM.

Pterodactyl-safe: only print() / input() / getpass.
UTF-8 stdout is reconfigured in Startall.py before this module loads,
so Unicode box-drawing and block characters work on all platforms.
"""

import getpass
import platform
import sys
from datetime import datetime

from runtime.constants.defaults import VERSION
from runtime.utils.logger       import get_logger, print_info, print_warn, print_err
from runtime.utils.helpers      import normalise_url

log = get_logger(__name__)

# ── ANSI palette ──────────────────────────────────────────────────────────────
_R   = "\033[0m"
_B   = "\033[1m"
_DIM = "\033[2m"
_I   = "\033[3m"      # italic

_CYAN    = "\033[96m"
_YELLOW  = "\033[93m"
_WHITE   = "\033[97m"
_GREEN   = "\033[92m"
_MAGENTA = "\033[95m"
_BLUE    = "\033[94m"
_RED     = "\033[91m"
_ORANGE  = "\033[38;5;208m"
_GREY    = "\033[38;5;244m"

# ── Layout ────────────────────────────────────────────────────────────────────
_W = 64          # inner banner width
_LINE = "─" * 70

# ── Block-letter HIBM ─────────────────────────────────────────────────────────
_HIBM = [
    "██╗  ██╗██╗██████╗ ███╗   ███╗",
    "██║  ██║██║██╔══██╗████╗ ████║",
    "███████║██║██████╔╝██╔████╔██║",
    "██╔══██║██║██╔══██╗██║╚██╔╝██║",
    "██║  ██║██║██████╔╝██║ ╚═╝ ██║",
    "╚═╝  ╚═╝╚═╝╚═════╝ ╚═╝     ╚═╝",
]

_TAGLINE = "Hit Intelligence Bot Manager"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _strip(text: str) -> str:
    """Strip ANSI codes for length calculation."""
    import re
    return re.sub(r"\033\[[0-9;]*m", "", text)


def _box_line(content: str = "", align: str = "left") -> str:
    """One line inside the banner box, padded to _W."""
    inner = _W
    if align == "center":
        raw_len = len(_strip(content))
        pad_l   = (inner - raw_len) // 2
        pad_r   = inner - raw_len - pad_l
        content = " " * pad_l + content + " " * pad_r
    else:
        raw_len = len(_strip(content))
        content = content + " " * max(0, inner - raw_len)
    return f"  {_CYAN}{_B}║{_R}  {content}  {_CYAN}{_B}║{_R}"


def _box_top()  -> str: return f"  {_CYAN}{_B}╔{'═' * (_W + 2)}╗{_R}"
def _box_bot()  -> str: return f"  {_CYAN}{_B}╚{'═' * (_W + 2)}╝{_R}"
def _box_sep()  -> str: return f"  {_CYAN}{_B}╠{'═' * (_W + 2)}╣{_R}"
def _box_sep2() -> str: return f"  {_CYAN}╟{'─' * (_W + 2)}╢{_R}"


# ── Public API ────────────────────────────────────────────────────────────────

def show_banner() -> None:
    """Print the full HIBM startup banner."""
    py_ver  = sys.version.split()[0]
    os_name = platform.system()
    arch    = platform.machine()
    now     = datetime.now().strftime("%Y-%m-%d  %H:%M")

    print()
    print(_box_top())
    print(_box_line())

    for art_line in _HIBM:
        coloured  = f"{_YELLOW}{_B}{art_line}{_R}"
        pad_l     = (_W - len(art_line)) // 2
        pad_r     = _W - len(art_line) - pad_l
        inner     = " " * pad_l + coloured + " " * pad_r
        print(f"  {_CYAN}{_B}║{_R}  {inner}  {_CYAN}{_B}║{_R}")

    print(_box_line())

    # Tagline
    tl_coloured = f"{_WHITE}{_B}{_TAGLINE}{_R}"
    print(_box_line(tl_coloured, align="center"))

    print(_box_line())
    print(_box_sep())
    print(_box_line())

    # System info
    sysinfo = f"{_MAGENTA}v{VERSION}{_R}  {_GREY}│{_R}  Python {_WHITE}{py_ver}{_R}  {_GREY}│{_R}  {os_name} {arch}"
    print(_box_line(sysinfo, align="center"))

    # Timestamp
    ts = f"{_GREY}{now}{_R}"
    print(_box_line(ts, align="center"))

    print(_box_line())
    print(_box_bot())
    print()


def section(title: str) -> None:
    """Print a styled section header."""
    pad   = max(0, 68 - len(title) - 4)
    left  = pad // 2
    right = pad - left
    print()
    print(f"  {_CYAN}┌{'─' * left}{_B}[ {title} ]{_R}{_CYAN}{'─' * right}┐{_R}")

def section_end() -> None:
    print(f"  {_CYAN}└{'─' * 68}┘{_R}")

def section_green(title: str) -> None:
    pad   = max(0, 68 - len(title) - 4)
    left  = pad // 2
    right = pad - left
    print()
    print(f"  {_GREEN}┌{'─' * left}{_B}[ {title} ]{_R}{_GREEN}{'─' * right}┐{_R}")
    print(f"  {_GREEN}│{_R}")

def section_green_end() -> None:
    print(f"  {_GREEN}│{_R}")
    print(f"  {_GREEN}└{'─' * 68}┘{_R}")
    print()


def divider() -> None:
    print(f"  {_GREY}{'─' * 70}{_R}")


def prompt_git_url() -> str:
    """Prompt for a git URL."""
    section("Repository Setup")
    print(f"  {_CYAN}│{_R}")
    print(f"  {_CYAN}│{_R}  {_DIM}Enter the GitHub/GitLab URL of your Discord bot repo.{_R}")
    print(f"  {_CYAN}│{_R}")

    while True:
        try:
            print(f"  {_CYAN}│{_R}  {_BLUE}{_B}›{_R}  {_B}Git URL{_R}  ", end="", flush=True)
            url = input().strip()
        except (KeyboardInterrupt, EOFError):
            print()
            _exit_clean()

        if url:
            print(f"  {_CYAN}│{_R}  {_GREEN}✔{_R}  {_DIM}{url}{_R}")
            print(f"  {_CYAN}│{_R}")
            return normalise_url(url)
        print(f"  {_CYAN}│{_R}  {_RED}✖  URL cannot be empty.{_R}")


def prompt_git_token() -> str | None:
    """Prompt for PAT — visible. Enter = skip."""
    print(f"  {_CYAN}│{_R}")
    print(f"  {_CYAN}│{_R}  {_DIM}Private repo? Paste your access token.{_R}")
    print(f"  {_CYAN}│{_R}  {_DIM}Press Enter to skip for public repos.{_R}")
    print(f"  {_CYAN}│{_R}")

    try:
        print(f"  {_CYAN}│{_R}  {_BLUE}{_B}›{_R}  {_B}Token{_R}  ", end="", flush=True)
        token = input().strip()
    except (KeyboardInterrupt, EOFError):
        print()
        _exit_clean()

    if not token:
        print(f"  {_CYAN}│{_R}  {_GREY}○  Public mode (no token).{_R}")
        print(f"  {_CYAN}│{_R}")
        log.info("Token skipped — public repository")
        return None

    print(f"  {_CYAN}│{_R}  {_GREEN}✔  Token received — private mode.{_R}")
    print(f"  {_CYAN}│{_R}")
    log.info("Token provided — private repository mode")
    return token


def show_clone_start(url: str) -> None:
    section("Cloning Repository")
    print(f"  {_CYAN}│{_R}")
    print(f"  {_CYAN}│{_R}  {_GREY}Source{_R}  {url}")
    print(f"  {_CYAN}│{_R}")


def show_scan_start() -> None:
    section("Scanning Repository")
    print(f"  {_CYAN}│{_R}")


def show_install_start() -> None:
    section("Installing Dependencies")
    print(f"  {_CYAN}│{_R}")


def show_launch_start(main_file: str) -> None:
    section("Launching Bot")
    print(f"  {_CYAN}│{_R}")
    print(f"  {_CYAN}│{_R}  {_GREEN}{_B}Entry point{_R}  {main_file}")
    print(f"  {_CYAN}│{_R}")


def show_cog_summary(cog_names: list) -> None:
    section("Cog Summary")
    print(f"  {_CYAN}│{_R}")
    if cog_names:
        count_str = f"{_GREEN}{_B}{len(cog_names)}{_R} cog(s) detected"
        print(f"  {_CYAN}│{_R}  {count_str}")
        for name in cog_names:
            print(f"  {_CYAN}│{_R}    {_CYAN}◆{_R}  {name}")
    else:
        print(f"  {_CYAN}│{_R}  {_GREY}No cogs — single-file bot.{_R}")
    print(f"  {_CYAN}│{_R}")


def show_polling_start(interval: int) -> None:
    section("Git Watch Active")
    print(f"  {_CYAN}│{_R}")
    print(
        f"  {_CYAN}│{_R}  {_MAGENTA}Watching for remote commits every "
        f"{_B}{interval}s{_R}{_MAGENTA}.{_R}"
    )
    print(f"  {_CYAN}│{_R}  {_GREY}Decision engine active — smart hot-reload / hot-restart.{_R}")
    print(f"  {_CYAN}│{_R}")
    print(f"  {_CYAN}└{'─' * 68}┘{_R}")
    print()
    # Live status bar
    pulse = f"{_GREEN}{_B}●  BOT LIVE{_R}"
    ctrl  = f"{_GREY}Ctrl+C to stop{_R}"
    print(f"  {pulse}   {ctrl}")
    print(f"  {_GREY}{'─' * 70}{_R}")
    print()


def ask_retry(context: str) -> bool:
    """Ask the user if they want to retry."""
    try:
        print(
            f"  {_YELLOW}{_B}Retry {context}?{_R}  "
            f"{_GREEN}[y]{_R} / {_RED}[N]{_R}  ",
            end="", flush=True,
        )
        answer = input().strip().lower()
        return answer in ("y", "yes")
    except (KeyboardInterrupt, EOFError):
        return False


def status_line(label: str, value: str, ok: bool = True) -> None:
    """Print a key-value status row inside a section."""
    indicator = f"{_GREEN}[OK]{_R}" if ok else f"{_RED}[!!]{_R}"
    print(f"  {_CYAN}│{_R}  {indicator}  {_B}{label:<18}{_R}  {value}")

def box_ok(msg: str) -> None:
    print(f"  {_CYAN}│{_R}  {_GREEN}✔{_R}  {msg}")

def box_info(msg: str) -> None:
    print(f"  {_CYAN}│{_R}  {_CYAN}◈{_R}  {msg}")

def box_err(msg: str) -> None:
    print(f"  {_CYAN}│{_R}  {_RED}✖{_R}  {msg}")

def box_warn(msg: str) -> None:
    print(f"  {_CYAN}│{_R}  {_YELLOW}⚠{_R}  {msg}")


def _exit_clean() -> None:
    print()
    print(f"  {_GREY}Goodbye.{_R}")
    print()
    sys.exit(0)
