"""
runtime/process/launcher.py
Concurrent pip install engine — preinstall-aware.

Strategy:
  1. The unloader already extracted preinstalled.zip → cache/packages/ and
     patched sys.path. Those packages are AVAILABLE with zero pip calls.
  2. For bot requirements.txt:
       a. Skip anything in the preinstalled set (already on sys.path)
       b. Skip anything already installed in the system env
       c. pip install the remainder in batches of 5 concurrently

  install_base_packages() is intentionally a no-op now — the unloader
  handles the base stack. It is kept as a function so Startall.py
  doesn't need changes in its step numbering.
"""

import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from importlib.metadata import packages_distributions
from typing import Optional

from runtime.constants.defaults import PREINSTALLED_SET, PIP_BATCH_SIZE, PIP_TIMEOUT_SECONDS
from runtime.utils.logger       import get_logger
from runtime.ui.startup         import box_ok, box_info, box_warn, box_err
from runtime.utils.config       import get as get_config

log = get_logger(__name__)

# Session-level installed cache (pkg_normalised_name → bool)
_install_cache: dict[str, bool] = {}

# Populated by Startall.py after unloader runs
_preloaded_names: set[str] = set()


# ── Public API ────────────────────────────────────────────────────────────────

def set_preloaded(names: set[str]) -> None:
    """
    Register the set of package names extracted by the unloader.
    Called once from Startall.py immediately after unload() returns.

    Args:
        names: Normalised package names (lowercase, underscores).
    """
    global _preloaded_names
    _preloaded_names = names
    log.debug("[launcher] Preloaded registry: %d packages", len(names))


def install_base_packages() -> None:
    """
    No-op — base packages are now served from preinstalled.zip by unloader.py.
    Kept for API compatibility so Startall.py step numbering doesn't change.
    """
    box_ok("Base packages served from preinstalled cache — no download needed.")
    log.info("[launcher] install_base_packages() skipped — unloader handled it")


def install_requirements(packages: list[str]) -> None:
    """
    Install packages from a bot's requirements.txt.

    Packages that are:
      - In the preinstalled bundle  → skipped (already on sys.path)
      - Already in the system env  → skipped
      - Neither                    → pip installed (5 concurrent)

    Args:
        packages: List of pip requirement specifiers, e.g. ['discord.py>=2.0', 'aiohttp'].
    """
    if not packages:
        box_info("No packages to install from requirements.txt.")
        return

    preinstalled_skip = []
    env_skip          = []
    to_install        = []

    for pkg in packages:
        name = _normalise_name(pkg)
        key  = name.lower().replace("-", "_")

        if key in _preloaded_names or key in PREINSTALLED_SET:
            preinstalled_skip.append(name)
        elif _is_env_installed(name):
            env_skip.append(name)
        else:
            to_install.append(pkg)

    # ── Report skips ──────────────────────────────────────────────────────────
    if preinstalled_skip:
        box_info(
            f"Skipped (preinstalled bundle): {len(preinstalled_skip)} — "
            + ", ".join(preinstalled_skip)
        )
        log.info("[launcher] Preinstalled skip: %s", preinstalled_skip)

    if env_skip:
        box_info(
            f"Skipped (already in env): {len(env_skip)} — "
            + ", ".join(env_skip)
        )
        log.info("[launcher] Env skip: %s", env_skip)

    if not to_install:
        print_ok("All requirements satisfied — nothing to download.")
        return

    # ── Install missing ones ──────────────────────────────────────────────────
    print()
    print(f"  ┌─ pip installing {len(to_install)} missing package(s) ─────────────────")
    _batch_install(to_install, label="req")
    print("  └────────────────────────────────────────────────────────────")
    print()


# ── Internal helpers ──────────────────────────────────────────────────────────

def _batch_install(packages: list[str], label: str = "") -> None:
    """Install packages in concurrent batches of PIP_BATCH_SIZE."""
    batch_size = get_config("pip_batch_size", PIP_BATCH_SIZE)
    timeout    = get_config("pip_timeout_seconds", PIP_TIMEOUT_SECONDS)
    total      = len(packages)
    installed  = 0
    failed     = []

    for batch_start in range(0, total, batch_size):
        batch     = packages[batch_start: batch_start + batch_size]
        batch_end = min(batch_start + batch_size, total)

        print_info(f"Installing {batch_start + 1}–{batch_end} of {total} ...")
        log.info("[pip:%s] Batch %d–%d: %s", label, batch_start + 1, batch_end, batch)

        with ThreadPoolExecutor(max_workers=batch_size) as executor:
            future_map = {
                executor.submit(_pip_install, pkg, timeout): pkg
                for pkg in batch
            }
            for future in as_completed(future_map):
                pkg = future_map[future]
                try:
                    success, pkg_name, err = future.result()
                    if success:
                        installed += 1
                        print_ok(f"  Installed: {pkg_name}")
                        log.info("[pip:%s] ✔ %s", label, pkg_name)
                    else:
                        failed.append(pkg_name)
                        print_err(f"  Failed:    {pkg_name} — {err}")
                        log.error("[pip:%s] ✖ %s: %s", label, pkg_name, err)
                except Exception as exc:
                    failed.append(pkg)
                    log.error("[pip:%s] Future error for %s: %s", label, pkg, exc)

    print_info(f"Done — {installed}/{total} installed, {len(failed)} failed.")
    if failed:
        log.warning("[pip:%s] Failed: %s", label, failed)


def _pip_install(package: str, timeout: int) -> tuple[bool, str, str]:
    """Run pip install for a single package. Returns (success, name, error)."""
    pkg_name = _normalise_name(package)
    cmd = [sys.executable, "-m", "pip", "install", "--quiet", package]
    try:
        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )
        if proc.returncode == 0:
            _install_cache[pkg_name.lower().replace("-", "_")] = True
            return True, pkg_name, ""
        err = (proc.stderr or proc.stdout or "unknown error").strip().splitlines()[-1]
        return False, pkg_name, err
    except subprocess.TimeoutExpired:
        return False, pkg_name, f"Timed out after {timeout}s"
    except Exception as exc:
        return False, pkg_name, str(exc)


def _is_env_installed(package_name: str) -> bool:
    """Check if a package is installed in the active Python environment."""
    key = package_name.lower().replace("-", "_")
    if key in _install_cache:
        return _install_cache[key]

    # importlib.metadata check
    try:
        dist_map = packages_distributions()
        for dist_name_list in dist_map.values():
            for dist_name in dist_name_list:
                if dist_name.lower().replace("-", "_") == key:
                    _install_cache[key] = True
                    return True
    except Exception:
        pass

    # pip show fallback
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pip", "show", "--quiet", package_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10,
        )
        result = proc.returncode == 0
        _install_cache[key] = result
        return result
    except Exception:
        return False


def _normalise_name(specifier: str) -> str:
    """Strip version specifiers to get the bare package name."""
    for sep in (">=", "<=", "==", "!=", "~=", ">", "<", "[", "@"):
        if sep in specifier:
            specifier = specifier[: specifier.index(sep)]
    return specifier.strip()
