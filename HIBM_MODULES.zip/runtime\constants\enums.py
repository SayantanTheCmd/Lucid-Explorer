"""
runtime/constants/enums.py
All enumerations used across the HIBM runtime.
"""

from enum import Enum, auto


class BotStatus(Enum):
    """Lifecycle state of a managed Discord bot process."""
    PENDING    = auto()   # Not yet started
    INSTALLING = auto()   # pip installs in progress
    STARTING   = auto()   # main.py being launched
    RUNNING    = auto()   # Subprocess alive and healthy
    CRASHED    = auto()   # Subprocess exited with non-zero code
    STOPPED    = auto()   # Gracefully stopped
    UPDATING   = auto()   # Pulling git update, temporarily paused


class InstallState(Enum):
    """State of a single pip package installation."""
    QUEUED    = auto()
    RUNNING   = auto()
    SUCCESS   = auto()
    SKIPPED   = auto()   # Already installed
    FAILED    = auto()


class UpdateStatus(Enum):
    """Result of a git poll cycle."""
    UP_TO_DATE  = auto()  # Local HEAD == remote HEAD
    BEHIND      = auto()  # Remote is ahead — update available
    ERROR       = auto()  # Could not reach remote / git error
    UNKNOWN     = auto()  # First poll, no baseline yet


class CloneStatus(Enum):
    """Result of a git clone operation."""
    SUCCESS       = auto()
    ALREADY_EXISTS = auto()
    AUTH_FAILED   = auto()
    NOT_FOUND     = auto()
    ERROR         = auto()


class RepoType(Enum):
    """Whether a repository is public or requires a token."""
    PUBLIC  = auto()
    PRIVATE = auto()
