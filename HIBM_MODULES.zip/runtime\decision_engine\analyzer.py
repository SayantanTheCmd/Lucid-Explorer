"""
runtime/decision_engine/analyzer.py
Analyze a git diff and classify every changed file so the
decision engine can choose the right update strategy.

Output:  DiffResult  — structured summary of what changed
"""

import os
import subprocess
from dataclasses import dataclass, field
from typing import Optional

from runtime.utils.logger import get_logger

log = get_logger(__name__)


# ── Change categories ─────────────────────────────────────────────────────────

class ChangeKind:
    COG_MODIFIED  = "cog_modified"   # existing cog .py modified
    COG_ADDED     = "cog_added"      # new cog .py file
    COG_DELETED   = "cog_deleted"    # cog .py removed
    COG_RENAMED   = "cog_renamed"    # cog .py renamed
    REQUIREMENTS  = "requirements"   # requirements.txt / requirement.txt
    MAIN_MODIFIED = "main_modified"  # bot entry-point (main.py etc.)
    OTHER_CODE    = "other_code"     # .py file outside cogs/ and not main
    STATIC        = "static"         # non-code / non-critical file


# ── Data classes ──────────────────────────────────────────────────────────────

@dataclass
class FileChange:
    path:     str
    kind:     str
    old_path: Optional[str] = None   # for renames


@dataclass
class DiffResult:
    old_sha: str
    new_sha: str
    changes: list = field(default_factory=list)         # list[FileChange]

    # Convenience summaries (populated by analyze())
    modified_cogs:        list = field(default_factory=list)  # dot-notation names
    added_cogs:           list = field(default_factory=list)
    deleted_cogs:         list = field(default_factory=list)
    requirements_changed: bool = False
    main_changed:         bool = False

    @property
    def has_any_cog_change(self) -> bool:
        return bool(self.modified_cogs or self.added_cogs or self.deleted_cogs)

    @property
    def has_static_only(self) -> bool:
        if not self.changes:
            return False
        return all(c.kind == ChangeKind.STATIC for c in self.changes)

    @property
    def summary(self) -> str:
        parts = []
        if self.modified_cogs:
            parts.append(f"cog_mod={self.modified_cogs}")
        if self.added_cogs:
            parts.append(f"cog_add={self.added_cogs}")
        if self.deleted_cogs:
            parts.append(f"cog_del={self.deleted_cogs}")
        if self.requirements_changed:
            parts.append("requirements")
        if self.main_changed:
            parts.append("main.py")
        if self.has_static_only:
            parts.append("static_only")
        return ", ".join(parts) or "no_changes"


# ── Extension / name sets ─────────────────────────────────────────────────────

_STATIC_EXTENSIONS = {
    ".env", ".txt", ".md", ".rst", ".json", ".yaml", ".yml",
    ".toml", ".ini", ".cfg", ".lock", ".png", ".jpg", ".jpeg",
    ".gif", ".ico", ".svg", ".bmp", ".webp",
    ".mp3", ".mp4", ".wav", ".ogg",
    ".db", ".sqlite", ".sqlite3",
    ".gitignore", ".gitattributes", ".editorconfig",
    ".dockerignore", ".zip", ".tar", ".gz",
}

_REQUIREMENTS_BASENAMES = {"requirements.txt", "requirement.txt", "requirements.in"}


# ── Public API ────────────────────────────────────────────────────────────────

def analyze(
    repo_path:     str,
    old_sha:       str,
    new_sha:       str,
    cog_dirs:      list[str] = None,
    main_filename: str = "main.py",
    main_dir_rel:  str = "",
) -> DiffResult:
    """
    Run git diff --name-status between old_sha and new_sha, classify
    each changed file, and return a structured DiffResult.

    Args:
        repo_path:     Absolute path to the bot repository.
        old_sha:       The commit SHA before the update.
        new_sha:       The new commit SHA.
        cog_dirs:      List of known top-level cog directories (default: ["cogs"]).
        main_filename: Bot entry-point filename (default: "main.py").
        main_dir_rel:  The relative directory of main.py within the repo (if any).

    Returns:
        DiffResult with all changes classified.
    """
    result = DiffResult(old_sha=old_sha, new_sha=new_sha)
    raw    = _git_diff(repo_path, old_sha, new_sha)

    if raw is None:
        log.warning("[Analyzer] git diff failed — empty result")
        return result

    for line in raw:
        line = line.strip()
        if not line:
            continue

        parts  = line.split("\t")
        status = parts[0][0].upper()          # M A D R C …
        if status == "R" and len(parts) >= 3:
            path     = parts[2]
            old_path = parts[1]
        else:
            path     = parts[1] if len(parts) > 1 else ""
            old_path = None

        if main_dir_rel and path.startswith(main_dir_rel):
            path = path[len(main_dir_rel):]
        if main_dir_rel and old_path and old_path.startswith(main_dir_rel):
            old_path = old_path[len(main_dir_rel):]

        fc = _classify(path, status, old_path, cog_dirs or ["cogs"], main_filename)
        result.changes.append(fc)
        _accumulate(result, fc)

    log.info(
        "[Analyzer] %s→%s  %d file(s)  %s",
        old_sha[:7], new_sha[:7], len(result.changes), result.summary,
    )
    return result


# ── Internal helpers ──────────────────────────────────────────────────────────

def _classify(
    path:          str,
    status:        str,
    old_path:      Optional[str],
    cog_dirs:      list[str],
    main_filename: str,
) -> FileChange:
    """Classify a single file path into a ChangeKind."""
    norm       = path.replace("\\", "/")
    parts      = norm.split("/")
    basename   = parts[-1].lower()
    ext        = os.path.splitext(basename)[1]

    # requirements.txt
    if basename in _REQUIREMENTS_BASENAMES:
        return FileChange(path=path, kind=ChangeKind.REQUIREMENTS)

    # main.py (top-level only)
    if basename == main_filename.lower() and len(parts) == 1:
        return FileChange(path=path, kind=ChangeKind.MAIN_MODIFIED)

    # Cog: <cog_dir>/**/*.py (nested cog dirs supported)
    in_cog_dir = (
        len(parts) >= 2
        and parts[0].lower() in cog_dirs
        and ext == ".py"
    )
    if in_cog_dir:
        if status == "A":
            kind = ChangeKind.COG_ADDED
        elif status == "D":
            kind = ChangeKind.COG_DELETED
        elif status == "R":
            kind = ChangeKind.COG_RENAMED
        else:
            kind = ChangeKind.COG_MODIFIED
        return FileChange(path=path, kind=kind, old_path=old_path)

    # Static / non-code
    if ext in _STATIC_EXTENSIONS or ext == "":
        return FileChange(path=path, kind=ChangeKind.STATIC)

    # .py file outside cogs/ — we treat as "other code" → safest to restart
    if ext == ".py":
        return FileChange(path=path, kind=ChangeKind.OTHER_CODE)

    return FileChange(path=path, kind=ChangeKind.STATIC)


def _accumulate(result: DiffResult, fc: FileChange) -> None:
    """Update the summary fields on DiffResult from a single FileChange."""
    k = fc.kind
    if k == ChangeKind.COG_MODIFIED:
        result.modified_cogs.append(_path_to_dotted(fc.path))
    elif k == ChangeKind.COG_ADDED:
        result.added_cogs.append(_path_to_dotted(fc.path))
    elif k in (ChangeKind.COG_DELETED, ChangeKind.COG_RENAMED):
        result.deleted_cogs.append(_path_to_dotted(fc.path))
    elif k == ChangeKind.REQUIREMENTS:
        result.requirements_changed = True
    elif k == ChangeKind.MAIN_MODIFIED:
        result.main_changed = True


def _path_to_dotted(path: str) -> str:
    """'cogs/music.py' → 'cogs.music'"""
    return path.replace("\\", "/").replace("/", ".").removesuffix(".py")


def _git_diff(repo_path: str, old_sha: str, new_sha: str) -> Optional[list]:
    """Run git diff --name-status -M and return lines."""
    try:
        proc = subprocess.run(
            ["git", "diff", "--name-status", "-M90", old_sha, new_sha],
            cwd=repo_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=15,
        )
        if proc.returncode != 0:
            log.warning("[Analyzer] git diff rc=%d: %s", proc.returncode, proc.stderr.strip())
            return None
        return proc.stdout.splitlines()
    except Exception as exc:
        log.warning("[Analyzer] git diff exception: %s", exc)
        return None
