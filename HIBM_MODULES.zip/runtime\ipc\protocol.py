"""
runtime/ipc/protocol.py
Message types and serialization for HIBM <-> Bot IPC.

Transport: newline-delimited JSON over TCP localhost socket.
Each message = one JSON object + "\\n".
"""

import json
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class MsgType(str, Enum):
    # HIBM -> Bot commands
    RELOAD_COG  = "reload_cog"
    STATUS      = "status"
    SHUTDOWN    = "shutdown"
    PING        = "ping"

    # Bot -> HIBM events / replies
    PONG         = "pong"
    READY        = "ready"
    COG_RELOADED = "cog_reloaded"
    COG_ERROR    = "cog_error"
    HEARTBEAT    = "heartbeat"
    STATUS_REPLY = "status_reply"


@dataclass
class Msg:
    type: MsgType
    id:   str  = field(default_factory=lambda: str(uuid.uuid4())[:8])
    data: dict = field(default_factory=dict)

    def encode(self) -> bytes:
        payload = {"type": self.type.value, "id": self.id, **self.data}
        return (json.dumps(payload) + "\n").encode("utf-8")

    @staticmethod
    def decode(line: str) -> "Msg":
        obj      = json.loads(line.strip())
        raw_type = obj.pop("type", "ping")
        msg_id   = obj.pop("id", "?")
        try:
            msg_type = MsgType(raw_type)
        except ValueError:
            msg_type = MsgType.PING
        return Msg(type=msg_type, id=msg_id, data=obj)
