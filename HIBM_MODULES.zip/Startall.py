"""
Startall.py
═══════════════════════════════════════════════════════════
HIBM — Hit Intelligence Bot Manager
The ONLY entry point for the entire system.

Boot sequence:
  0.  Unloader  — extract preinstalled.zip → cache/packages/, patch sys.path
  1.  Bootstrap — Python version, git, directories, config
  2.  Show banner
  3.  Prompt: git URL
  4.  Prompt: git token (optional)
  5.  Clone repository
  6.  Scan repository (requirements, cogs, main.py)
  7.  Validate repository
  8.  Base packages  → served from preinstalled cache (no download)
  9.  Requirements   → skip preinstalled/env, pip only missing packages
  10. Display cog summary
  11. Start IPC server (localhost:0) + inject wrapper into bot dir
  12. Launch bot via _hibm_launch.py (IPC-enabled)
  13. Start git poller (every 5s, daemon thread)
  14. Wait — hold process alive until bot exits or Ctrl+C
═══════════════════════════════════════════════════════════
"""

import sys
import os

# ── ANSI color support — must be FIRST, before any print ─────────────────────
# Resolve path manually so we don't need sys.path set up yet.
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

# Force UTF-8 output (fixes cp1252 encoding errors on Windows)
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# Enable Windows Virtual Terminal Processing so ANSI codes render as colors.
# On non-TTY (piped/redirected), ANSI codes are stripped so output stays clean.
from runtime.utils.ansi import enable as _enable_ansi
_enable_ansi()

# ── Step 0: Unloader — must run FIRST before other runtime imports ───────────────
# This extracts preinstalled.zip → cache/packages/ and patches sys.path so
# all pre-compiled packages are importable before anything else is imported.
import unloader.unloader as _unloader_mod

_preload = _unloader_mod.unload(verbose=True)

if not _preload.success and not _preload.zip_missing:
    # Extraction error — fatal
    print(f"\n  [FATAL] Unloader failed: {_preload.error}\n")
    sys.exit(1)

# If download+extract failed entirely, exit fatally
if not _preload.success and _preload.error:
    print(f"\n  [FATAL] {_preload.error}\n")
    sys.exit(1)

# ── Imports (after unloader has patched sys.path) ─────────────────────────────
from runtime.core         import bootstrap
from runtime.ui           import startup
from runtime.updater      import clone as cloner
from runtime.updater      import pull  as poller_mod
from runtime.repository   import scanner, validator
from runtime.process      import launcher as pip_launcher
from runtime.process      import manager  as bot_manager
from runtime.ipc.server   import IPCServer
from runtime.wrapper      import injector
from runtime.decision_engine.analyzer  import analyze
from runtime.decision_engine.strategies import decide, describe
from runtime.decision_engine.executor  import execute
from runtime.utils.logger import get_logger, print_ok, print_err, print_info, print_warn
from runtime.utils.config import get as get_config
from runtime.constants.enums import CloneStatus
from runtime.constants.paths import PREINSTALLED_ZIP, CACHE_PACKAGES

log = get_logger("startall")

# Register preloaded packages with the launcher so it can skip pip for them
pip_launcher.set_preloaded(_preload.available_names)


# ── Shutdown cleanup — two-phase: marker now, wipe on next startup ─────────────
import atexit
import signal


_cleanup_done = False   # guard — prevent running twice if both finally + atexit fire


def _cleanup() -> None:
    """
    Shutdown cleanup — called from try/finally, atexit, and SIGTERM handler.

    Why two-phase?
      Windows locks every .pyd file (compiled extension) that Python has
      imported. shutil.rmtree silently skips locked files, leaving the whole
      cache/packages/ directory behind.

    Solution:
      Phase 1 (NOW, while process is running):
        - Delete preinstalled.zip  ← not locked, always succeeds
        - Write cache/packages/.pending_cleanup marker

      Phase 2 (NEXT startup, in unloader.py, BEFORE sys.path is patched):
        - Nothing is loaded yet → no locks → rmtree succeeds 100%
        - Wipes cache/packages/ completely, then re-downloads + re-extracts
    """
    global _cleanup_done
    if _cleanup_done:
        return
    _cleanup_done = True

    print()
    print("  [HIBM] Shutdown — marking packages for cleanup ...")

    # Phase 1a: delete the zip (never locked by Python)
    if os.path.isfile(PREINSTALLED_ZIP):
        try:
            os.remove(PREINSTALLED_ZIP)
            print("  [HIBM]   Deleted : preinstalled.zip")
        except OSError as e:
            print(f"  [HIBM]   Warning  : could not delete zip: {e}")

    # Phase 1b: write the pending-cleanup marker inside cache/packages/
    # Unloader reads this on next run BEFORE importing anything.
    _marker = os.path.join(CACHE_PACKAGES, ".pending_cleanup")
    if os.path.isdir(CACHE_PACKAGES):
        try:
            with open(_marker, "w") as _f:
                _f.write("1")
            print("  [HIBM]   Marked  : cache/packages/ for deletion on next start")
        except OSError as e:
            print(f"  [HIBM]   Warning  : could not write cleanup marker: {e}")

    print("  [HIBM] Next run will wipe packages before loading anything.")
    print()


# Backup: fires on sys.exit() if try/finally was somehow skipped
atexit.register(_cleanup)


# SIGTERM handler — Linux process managers (Pterodactyl) send this on stop
def _sigterm_handler(signum, frame):
    """On SIGTERM: run cleanup then exit cleanly."""
    _cleanup()
    sys.exit(0)


try:
    signal.signal(signal.SIGTERM, _sigterm_handler)
except (OSError, ValueError):
    pass   # SIGTERM unavailable on some Windows configs


def main() -> None:
    # ── Step 1: Bootstrap ─────────────────────────────────────────────────────
    if not bootstrap.run():
        sys.exit(1)

    # ── Step 2: Banner ────────────────────────────────────────────────────────
    startup.show_banner()

    # ── Step 3 & 4: Git URL + Token ───────────────────────────────────────────
    git_url = startup.prompt_git_url()
    token   = startup.prompt_git_token()

    # ── Step 5: Clone ─────────────────────────────────────────────────────────
    startup.show_clone_start(git_url)
    clone_result = cloner.clone(git_url, token)

    if clone_result.status in (CloneStatus.AUTH_FAILED, CloneStatus.NOT_FOUND, CloneStatus.ERROR):
        print_err(f"Clone failed: {clone_result.error_msg}")
        if startup.ask_retry("clone"):
            token = startup.prompt_git_token()
            clone_result = cloner.clone(git_url, token)
            if clone_result.status not in (CloneStatus.SUCCESS, CloneStatus.ALREADY_EXISTS):
                print_err("Clone failed again. Exiting.")
                sys.exit(1)
        else:
            sys.exit(1)

    repo_name = clone_result.repo_name
    repo_path = clone_result.repo_path

    print_ok(f"Repository ready at: {repo_path}")
    startup.divider()

    # ── Step 6: Scan ──────────────────────────────────────────────────────────
    startup.show_scan_start()
    scan = scanner.scan(repo_path, repo_name)

    # ── Step 7: Validate ──────────────────────────────────────────────────────
    startup.section("Validating Repository")
    val = validator.validate(scan)
    if not val.ok:
        print_err("Repository failed validation. Cannot continue.")
        sys.exit(1)

    startup.divider()

    # ── Step 8 & 9: Dependencies ──────────────────────────────────────────────
    startup.show_install_start()

    print_info("Step 1/2 — Base packages (from preinstalled bundle)")
    pip_launcher.install_base_packages()   # No-op — served from cache

    if scan.has_requirements:
        print_info(f"Step 2/2 — requirements.txt ({len(scan.raw_requirements)} entries)")
        pip_launcher.install_requirements(scan.raw_requirements)
    else:
        print_info("Step 2/2 — No requirements.txt — skipping.")

    startup.divider()

    # ── Step 10: Cog summary ────────────────────────────────────────────────
    startup.show_cog_summary(
        scan.cog_result.names if scan.cog_result else []
    )

    startup.divider()

    # ── Step 11: IPC server + wrapper injection ────────────────────────────────
    startup.section("IPC & Wrapper")
    ipc = IPCServer()
    ipc_port = ipc.start()
    print_ok(f"IPC server listening on port {ipc_port}")

    launch_cmd = injector.inject(repo_path, scan.main_path)
    print_ok(f"Wrapper injected → {os.path.basename(launch_cmd[-1])}")
    startup.divider()

    # ── Step 12: Launch bot ───────────────────────────────────────────────────
    startup.show_launch_start(os.path.basename(scan.main_path))
    bot = bot_manager.BotProcess(
        repo_name,
        scan.main_path,
        cmd_override=launch_cmd,
        ipc_port=ipc_port,
    )

    if not bot.start():
        print_err("Bot failed to launch. Check logs for details.")
        sys.exit(1)

    # ── Step 13: Start git poller ─────────────────────────────────────────────
    poll_interval = get_config("git_poll_interval", 5)
    startup.show_polling_start(poll_interval)

    # Build the update callback now that we have bot, ipc, scan in scope
    def _on_update_cb(rname: str, old_sha: str, new_sha: str) -> None:
        _on_update(rname, old_sha, new_sha, bot, ipc, repo_path, scan)

    git_poller = poller_mod.start_poller(
        repo_name=repo_name,
        repo_path=repo_path,
        interval=poll_interval,
        on_update_available=_on_update_cb,
    )

    # ── Step 14: Hold — wait for bot to exit ──────────────────────────────────
    log.info("HIBM fully started — waiting for bot process")
    try:
        import time
        while True:
            exit_code = bot.wait()
            if getattr(bot, "is_restarting", False):
                # Wait for the hot restart to finish bringing the bot back up
                while getattr(bot, "is_restarting", False):
                    time.sleep(0.1)
                continue
            break
    except KeyboardInterrupt:
        print()
        print_info("Interrupt received — stopping bot ...")
        bot.stop()
        git_poller.stop()
        ipc.stop()
        log.info("HIBM shut down via KeyboardInterrupt")
        return   # falls through to finally in __main__

    git_poller.stop()
    ipc.stop()

    if exit_code != 0:
        print_err(f"Bot exited with code {exit_code}.")
        log.error("Bot exited with code %d", exit_code)
    else:
        print_ok("Bot exited cleanly.")



def _on_update(
    repo_name:  str,
    old_sha:    str,
    new_sha:    str,
    bot:        "bot_manager.BotProcess",
    ipc:        "IPCServer",
    repo_path:  str,
    scan,
) -> None:
    """
    Decision engine callback — fired by GitPoller when a new commit is found.

    Flow:
      1. Analyze the diff (what files changed?)
      2. Decide the action (hot_reload / hot_restart / pull_only)
      3. Execute the action
    """
    log.info("[%s] Update detected: %s → %s", repo_name, old_sha[:7], new_sha[:7])
    print(f"\n  [GIT] New commit detected on '{repo_name}': "
          f"{old_sha[:7]} → {new_sha[:7]}", flush=True)

    main_dir_rel = ""
    if scan.main_path:
        main_dir = os.path.dirname(scan.main_path)
        if main_dir != repo_path:
            main_dir_rel = os.path.relpath(main_dir, repo_path).replace("\\", "/") + "/"

    # ── 1. Analyze ────────────────────────────────────────────────────────────
    cog_dirs = set()
    if scan.cog_result:
        for c in scan.cog_result.cogs:
            rel = os.path.relpath(c.file_path, repo_path).replace("\\", "/")
            if main_dir_rel and rel.startswith(main_dir_rel):
                rel = rel[len(main_dir_rel):]
            parts = rel.split("/")
            if len(parts) > 1:
                cog_dirs.add(parts[0].lower())
    if not cog_dirs:
        cog_dirs.add("cogs")

    main_fn = os.path.basename(scan.main_path) if scan.main_path else "main.py"
    diff    = analyze(repo_path, old_sha, new_sha,
                      cog_dirs=list(cog_dirs), main_filename=main_fn,
                      main_dir_rel=main_dir_rel)

    # ── 2. Decide ─────────────────────────────────────────────────────────────
    action = decide(diff)
    reason = describe(action, diff)
    print(f"  [Decision] {reason}", flush=True)
    log.info("[%s] Decision: %s — %s", repo_name, action.value, reason)

    # ── 3. Execute ────────────────────────────────────────────────────────────
    execute(
        action=action,
        diff=diff,
        bot=bot,
        ipc=ipc,
        repo_path=repo_path,
        scan_result=scan,
    )


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise          # let sys.exit() propagate normally (atexit fires after)
    except Exception as exc:
        log.exception("Unhandled exception in main: %s", exc)
        print(f"\n  [FATAL] Unexpected error: {exc}\n")
    finally:
        # This block ALWAYS runs — Ctrl+C, exception, normal return, sys.exit()
        # The _cleanup_done guard prevents double-deletion if atexit also fires.
        _cleanup()
