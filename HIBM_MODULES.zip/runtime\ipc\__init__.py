"""runtime/ipc — HIBM ↔ Bot IPC layer."""
from runtime.ipc.server   import IPCServer
from runtime.ipc.protocol import Msg, MsgType

__all__ = ["IPCServer", "Msg", "MsgType"]
