"""
runtime/repository/scanner.py
Scan a cloned repository to discover:
  - The requirements file (requirements.txt / requirement.txt)
  - The bot's main entry point (main.py / bot.py / run.py …)
  - All cog files (via cog_mapper)
"""

import os
from dataclasses import dataclass, field
from typing import Optional

from runtime.constants.defaults    import REQUIREMENTS_CANDIDATES, MAIN_FILE_CANDIDATES
from runtime.utils.logger          import get_logger, print_ok, print_warn, print_info
from runtime.utils.filesystem      import find_file
from runtime.cog_mapper.mapper     import map_cogs, CogMapResult

log = get_logger(__name__)


@dataclass
class ScanResult:
    repo_path:        str
    repo_name:        str
    requirements_path: Optional[str]   = None   # Absolute path to req file
    main_path:        Optional[str]   = None    # Absolute path to main.py
    cog_result:       Optional[CogMapResult] = None
    raw_requirements: list[str]       = field(default_factory=list)  # Lines from req file

    @property
    def has_requirements(self) -> bool:
        return self.requirements_path is not None

    @property
    def cog_count(self) -> int:
        return self.cog_result.count if self.cog_result else 0


def scan(repo_path: str, repo_name: str) -> ScanResult:
    """
    Scan the cloned repository and return a ScanResult.

    Args:
        repo_path: Absolute path to the cloned repo directory.
        repo_name: Short name used in log messages.

    Returns:
        ScanResult populated with discovered paths and metadata.
    """
    result = ScanResult(repo_path=repo_path, repo_name=repo_name)

    # ── 1. Requirements file ───────────────────────────────────────────────────
    print_info("Scanning for requirements file ...")
    for candidate in REQUIREMENTS_CANDIDATES:
        req_path = find_file(repo_path, candidate)
        if req_path:
            result.requirements_path = req_path
            result.raw_requirements  = _parse_requirements(req_path)
            print_ok(f"Found: {os.path.relpath(req_path, repo_path)}"
                     f"  ({len(result.raw_requirements)} packages)")
            log.info("[%s] Requirements file: %s", repo_name, req_path)
            break

    if not result.has_requirements:
        print_warn("No requirements.txt found — only base packages will be installed.")
        log.info("[%s] No requirements file found", repo_name)

    # ── 2. Cog detection ──────────────────────────────────────────────────────
    print_info("Scanning for Discord cogs ...")
    result.cog_result = map_cogs(repo_path)

    if result.cog_count > 0:
        cog_names = ", ".join(result.cog_result.names)
        print_ok(f"Found {result.cog_count} cog(s): {cog_names}")
    else:
        print_warn("No cogs detected (single-file bot or non-standard structure).")

    # ── 3. Main file ───────────────────────────────────────────────────────────
    print_info("Searching for bot entry point ...")
    for candidate in MAIN_FILE_CANDIDATES:
        main_path = find_file(repo_path, candidate)
        if main_path:
            result.main_path = main_path
            rel = os.path.relpath(main_path, repo_path)
            print_ok(f"Entry point: {rel}")
            log.info("[%s] Main file: %s", repo_name, main_path)
            break

    if not result.main_path:
        print_warn(
            "Could not find a recognised entry point "
            f"(tried: {', '.join(MAIN_FILE_CANDIDATES)})"
        )
        log.warning("[%s] No main file found", repo_name)

    return result


def _parse_requirements(req_path: str) -> list[str]:
    """
    Parse a requirements.txt file into a list of package specifiers.
    Strips comments, blank lines, and -r includes.
    """
    packages = []
    try:
        with open(req_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("-"):
                    continue
                # Remove inline comments
                if " #" in line:
                    line = line[: line.index(" #")].strip()
                if line:
                    packages.append(line)
    except OSError as exc:
        log.warning("Could not read requirements file: %s", exc)
    return packages
