"""
runtime/constants/paths.py
Centralised path definitions for the entire HIBM runtime.
All paths are derived from the project root so the project
is relocatable without touching any other file.
"""

import os

# ── Root ──────────────────────────────────────────────────────────────────────
# __file__ → constants/paths.py → runtime/constants → runtime → HIBM
_CONSTANTS_DIR = os.path.dirname(os.path.abspath(__file__))
_RUNTIME_DIR   = os.path.dirname(_CONSTANTS_DIR)
ROOT_DIR       = os.path.dirname(_RUNTIME_DIR)          # HIBM/

# ── Top-level directories ─────────────────────────────────────────────────────
RUNTIME_DIR    = _RUNTIME_DIR                           # HIBM/runtime/
CONFIG_DIR     = os.path.join(ROOT_DIR, "config")       # HIBM/config/
REPOSITORIES   = os.path.join(ROOT_DIR, "repositories") # HIBM/repositories/
CACHE_DIR      = os.path.join(ROOT_DIR, "cache")        # HIBM/cache/
LOGS_DIR       = os.path.join(ROOT_DIR, "logs")         # HIBM/logs/
PLUGINS_DIR    = os.path.join(ROOT_DIR, "plugins")      # HIBM/plugins/
DATA_DIR       = os.path.join(ROOT_DIR, "data")         # HIBM/data/

# ── Cache sub-directories ─────────────────────────────────────────────────────
CACHE_COMMITS   = os.path.join(CACHE_DIR, "commits")    # HIBM/cache/commits/
CACHE_DOWNLOADS = os.path.join(CACHE_DIR, "downloads")  # HIBM/cache/downloads/
CACHE_TEMP      = os.path.join(CACHE_DIR, "temp")       # HIBM/cache/temp/
CACHE_PACKAGES  = os.path.join(CACHE_DIR, "packages")   # HIBM/cache/packages/ (unloader target)

# ── Unloader ──────────────────────────────────────────────────────────────────
UNLOADER_DIR    = os.path.join(ROOT_DIR, "unloader")                        # HIBM/unloader/
PREINSTALLED_ZIP = os.path.join(UNLOADER_DIR, "preinstalled.zip")           # HIBM/unloader/preinstalled.zip

# ── Config files ──────────────────────────────────────────────────────────────
SETTINGS_FILE    = os.path.join(CONFIG_DIR, "settings.json")
REPOS_FILE       = os.path.join(CONFIG_DIR, "repositories.json")
RULES_FILE       = os.path.join(CONFIG_DIR, "decision_rules.json")

# ── Log files ─────────────────────────────────────────────────────────────────
LOG_LAUNCHER = os.path.join(LOGS_DIR, "launcher.log")
LOG_UPDATER  = os.path.join(LOGS_DIR, "updater.log")
LOG_IPC      = os.path.join(LOGS_DIR, "ipc.log")
LOG_RUNTIME  = os.path.join(LOGS_DIR, "runtime.log")

# ── Directories that must exist before the runtime starts ────────────────────
REQUIRED_DIRS = [
    CONFIG_DIR,
    REPOSITORIES,
    CACHE_DIR,
    CACHE_COMMITS,
    CACHE_DOWNLOADS,
    CACHE_TEMP,
    CACHE_PACKAGES,
    LOGS_DIR,
    PLUGINS_DIR,
    DATA_DIR,
    UNLOADER_DIR,
]
