"""
runtime/process/watchdog.py
Phase 2 stub — auto-restart on crash.

Currently this module is a no-op placeholder. In Phase 2, the watchdog
will monitor BotProcess.is_running and trigger restart logic based on
the decision engine's policy.
"""

from runtime.utils.logger import get_logger

log = get_logger(__name__)


class Watchdog:
    """
    Stub watchdog. Not active in Phase 1.

    In Phase 2, this will:
      - Monitor the BotProcess exit code
      - Apply restart policy (max retries, backoff)
      - Notify the decision engine
    """

    def __init__(self, bot_process, max_retries: int = 3):
        self.bot_process = bot_process
        self.max_retries = max_retries
        log.debug("Watchdog initialised (stub — Phase 2)")

    def start(self):
        log.debug("Watchdog.start() called — no-op in Phase 1")

    def stop(self):
        log.debug("Watchdog.stop() called — no-op in Phase 1")
