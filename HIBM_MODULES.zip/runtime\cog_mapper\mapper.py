"""
runtime/cog_mapper/mapper.py
Detect and count Discord cogs in a cloned repository.

A "cog" is identified by scanning every .py file for known Discord.py
patterns (see defaults.COG_PATTERNS). Both classic cogs (commands.Cog)
and app_commands groups are detected.
"""

import os
import re
from dataclasses import dataclass, field
from typing import Optional

from runtime.constants.defaults import COG_PATTERNS
from runtime.utils.logger       import get_logger
from runtime.utils.filesystem   import find_files_by_extension

log = get_logger(__name__)


@dataclass
class CogInfo:
    """Information about a single detected cog file."""
    file_path: str
    class_names: list[str] = field(default_factory=list)
    pattern_matched: str = ""

    @property
    def filename(self) -> str:
        return os.path.basename(self.file_path)


@dataclass
class CogMapResult:
    cogs: list[CogInfo] = field(default_factory=list)

    @property
    def count(self) -> int:
        return len(self.cogs)

    @property
    def names(self) -> list[str]:
        return [c.filename for c in self.cogs]


# Regex to extract class names that inherit from anything (for display)
_CLASS_RE = re.compile(r"^class\s+(\w+)\s*[\(:]", re.MULTILINE)


def map_cogs(repo_path: str) -> CogMapResult:
    """
    Walk all .py files in `repo_path` and identify Discord cogs.

    Returns:
        CogMapResult containing a list of CogInfo objects.
    """
    result = CogMapResult()
    py_files = find_files_by_extension(repo_path, ".py")

    for filepath in py_files:
        cog_info = _inspect_file(filepath)
        if cog_info:
            result.cogs.append(cog_info)
            log.debug("Cog detected: %s (pattern: %s)", cog_info.filename, cog_info.pattern_matched)

    log.info(
        "Cog scan complete — %d cog(s) found in %d .py files",
        result.count, len(py_files),
    )
    return result


def _inspect_file(filepath: str) -> Optional[CogInfo]:
    """
    Return a CogInfo if the file contains Discord cog patterns, else None.
    Handles encoding errors gracefully.
    """
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
    except OSError:
        return None

    for pattern in COG_PATTERNS:
        if pattern in content:
            class_names = _CLASS_RE.findall(content)
            return CogInfo(
                file_path=filepath,
                class_names=class_names,
                pattern_matched=pattern,
            )

    return None
