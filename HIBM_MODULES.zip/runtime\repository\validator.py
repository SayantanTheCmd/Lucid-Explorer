"""
runtime/repository/validator.py
Validate that a scanned repository is a runnable Discord bot.

Runs after scanner.scan() and before the install/launch sequence.
"""

from runtime.repository.scanner import ScanResult
from runtime.utils.logger       import get_logger, print_ok, print_warn, print_err

log = get_logger(__name__)


class ValidationResult:
    def __init__(self):
        self.ok       = True
        self.warnings = []
        self.errors   = []

    def warn(self, msg: str):
        self.warnings.append(msg)
        print_warn(msg)
        log.warning(msg)

    def error(self, msg: str):
        self.errors.append(msg)
        self.ok = False
        print_err(msg)
        log.error(msg)


def validate(scan: ScanResult) -> ValidationResult:
    """
    Validate a ScanResult.

    Returns:
        ValidationResult — check .ok to know if it's safe to continue.
    """
    vr = ValidationResult()

    # Fatal: no entry point found
    if not scan.main_path:
        vr.error(
            f"No entry point found in '{scan.repo_name}'. "
            f"Expected one of: main.py, bot.py, run.py, start.py, app.py"
        )

    # Warning: no requirements file
    if not scan.has_requirements:
        vr.warn(
            f"'{scan.repo_name}' has no requirements.txt — "
            "only pre-installed base packages will be available."
        )

    # Warning: no cogs detected (could be a single-file bot, that's fine)
    if scan.cog_count == 0:
        vr.warn(
            f"No cogs detected in '{scan.repo_name}' — "
            "assuming single-file bot structure."
        )

    if vr.ok:
        print_ok(f"Validation passed for '{scan.repo_name}'")
        log.info("[%s] Validation passed", scan.repo_name)
    else:
        log.error("[%s] Validation FAILED — cannot launch", scan.repo_name)

    return vr
