"""
runtime/core/bootstrap.py
Pre-flight checks and environment setup that runs before any UI is shown.

Responsibilities:
  1. Verify Python version (>= 3.10)
  2. Verify git is installed
  3. Create all required runtime directories
  4. Load config from settings.json
  5. Return a Go/No-Go signal to the entry point
"""

import sys

from runtime.constants.paths    import REQUIRED_DIRS
from runtime.constants.defaults import VERSION
from runtime.utils.logger       import get_logger
from runtime.utils.config       import load as load_config
from runtime.utils.filesystem   import ensure_dirs
from runtime.utils.helpers      import is_git_installed, python_version_ok

log = get_logger(__name__)


def run() -> bool:
    """
    Execute all bootstrap checks and setup.

    Returns:
        True  — all checks passed, safe to continue
        False — a fatal condition was found; caller should sys.exit()
    """
    log.info("HIBM v%s — bootstrap starting", VERSION)

    # ── 1. Python version ─────────────────────────────────────────────────────
    if not python_version_ok(3, 10):
        ver = sys.version.split()[0]
        log.critical(
            "Python 3.10+ is required. Running Python %s. "
            "Please upgrade and restart.",
            ver,
        )
        print(
            f"\n  [FATAL] Python 3.10+ required. "
            f"You are running Python {ver}.\n"
        )
        return False

    log.debug("Python version OK (%s)", sys.version.split()[0])

    # ── 2. Git ────────────────────────────────────────────────────────────────
    if not is_git_installed():
        log.critical(
            "git is not installed or not on PATH. "
            "Please install git and restart."
        )
        print("\n  [FATAL] git not found. Install git and ensure it is on PATH.\n")
        return False

    log.debug("git is available")

    # ── 3. Directory structure ────────────────────────────────────────────────
    try:
        ensure_dirs(*REQUIRED_DIRS)
        log.debug("All required directories are present")
    except OSError as exc:
        log.critical("Failed to create runtime directories: %s", exc)
        return False

    # ── 4. Config ─────────────────────────────────────────────────────────────
    cfg = load_config()
    log.debug("Config loaded — %d keys", len(cfg))

    log.info("Bootstrap complete — all checks passed")
    return True
