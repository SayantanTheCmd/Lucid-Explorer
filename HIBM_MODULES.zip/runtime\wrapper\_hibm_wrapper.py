"""
runtime/wrapper/_hibm_wrapper.py
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Bot-side IPC wrapper — injected into the bot's process by HIBM.

This file is COPIED into the bot's repository directory by injector.py
and exec()'d BEFORE main.py runs. It must be fully self-contained
(stdlib only — the HIBM runtime/ is NOT on the bot's sys.path).

What it does:
  1. Connects to HIBM's IPC server via HIBM_IPC_PORT env var.
  2. Monkey-patches discord.ext.commands.Bot (and Client) __init__
     to capture the bot instance the moment it's constructed.
  3. Starts two daemon threads:
       - IPC receiver: reads commands from HIBM, dispatches handlers
       - Heartbeat:    sends periodic heartbeat to HIBM
  4. For `reload_cog`:
       Uses asyncio.run_coroutine_threadsafe() to safely call
       bot.reload_extension() on the bot's event loop — works for
       both discord.py v1.x (sync) and v2.x (async).

This file intentionally does NOT import anything from runtime/
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

import asyncio
import inspect
import json
import os
import socket
import sys
import threading
import time
import uuid as _uuid_mod

# ── Config from environment ───────────────────────────────────────────────────
_IPC_PORT = int(os.environ.get("HIBM_IPC_PORT", "0"))
_IPC_HOST = "127.0.0.1"
_HB_INTERVAL = 10        # heartbeat every N seconds
_RECONNECT_DELAY = 3     # seconds between reconnect attempts

# ── Shared mutable state ──────────────────────────────────────────────────────
_state: dict = {
    "bot":      None,     # discord.ext.commands.Bot instance
    "sock":     None,     # socket connected to HIBM
    "running":  True,
    "ready":    False,    # True once bot fires on_ready
}
_send_lock = threading.Lock()


# ── Logging (no runtime.utils here) ──────────────────────────────────────────
def _log(msg: str) -> None:
    print(f"  [HIBM-IPC] {msg}", flush=True)

def _err(msg: str) -> None:
    print(f"  [HIBM-IPC] ERR: {msg}", flush=True)


# ── IPC send ──────────────────────────────────────────────────────────────────
def _send(msg_type: str, **kwargs) -> None:
    """Send a JSON message to HIBM. Fire-and-forget."""
    with _send_lock:
        sock = _state.get("sock")
        if not sock:
            return
        payload = json.dumps({
            "type": msg_type,
            "id":   str(_uuid_mod.uuid4())[:8],
            **kwargs,
        }) + "\n"
        try:
            sock.sendall(payload.encode("utf-8"))
        except Exception:
            _state["sock"] = None


# ── IPC connection ────────────────────────────────────────────────────────────
def _connect() -> bool:
    if not _IPC_PORT:
        return False
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((_IPC_HOST, _IPC_PORT))
        _state["sock"] = s
        _log(f"Connected to HIBM on port {_IPC_PORT}")
        return True
    except Exception as exc:
        _err(f"Cannot connect to HIBM IPC ({exc})")
        return False


# ── Command handlers ──────────────────────────────────────────────────────────
def _on_reload_cog(msg: dict) -> None:
    msg_id   = msg.get("id", "?")
    cog_name = msg.get("cog", "")
    bot      = _state.get("bot")

    if not bot:
        _send("cog_error", id=msg_id, cog=cog_name, error="bot_not_ready")
        return

    loop = getattr(bot, "loop", None)

    # ── Handle both sync (dpy v1) and async (dpy v2 / nextcord / py-cord) ────
    reload_fn = getattr(bot, "reload_extension", None)
    if reload_fn is None:
        _send("cog_error", id=msg_id, cog=cog_name, error="no_reload_extension")
        return

    if inspect.iscoroutinefunction(reload_fn):
        # discord.py v2 / nextcord / py-cord — async
        async def _do_reload():
            current = cog_name
            while True:
                try:
                    await bot.reload_extension(current)
                    _send("cog_reloaded", id=msg_id, cog=current, ok=True)
                    _log(f"Hot reloaded: {current}")
                    break
                except Exception as exc:
                    err_str = str(exc)
                    if "has not been loaded" in err_str and "." in current:
                        current = current.rsplit(".", 1)[0]
                        continue
                    _send("cog_reloaded", id=msg_id, cog=cog_name, ok=False,
                          error=err_str)
                    _err(f"Reload failed ({cog_name}): {exc}")
                    break

        if loop and loop.is_running():
            asyncio.run_coroutine_threadsafe(_do_reload(), loop)
        else:
            _send("cog_error", id=msg_id, cog=cog_name, error="loop_not_running")
    else:
        # discord.py v1 — synchronous
        current = cog_name
        while True:
            try:
                bot.reload_extension(current)
                _send("cog_reloaded", id=msg_id, cog=current, ok=True)
                _log(f"Hot reloaded: {current}")
                break
            except Exception as exc:
                err_str = str(exc)
                if "has not been loaded" in err_str and "." in current:
                    current = current.rsplit(".", 1)[0]
                    continue
                _send("cog_reloaded", id=msg_id, cog=cog_name, ok=False, error=err_str)
                _err(f"Reload failed ({cog_name}): {exc}")
                break


def _on_ping(msg: dict) -> None:
    _send("pong", id=msg.get("id", "?"))


def _on_status(msg: dict) -> None:
    bot      = _state.get("bot")
    msg_id   = msg.get("id", "?")
    name     = str(getattr(bot, "user", "not_ready")) if bot else "not_ready"
    guilds   = len(getattr(bot, "guilds", [])) if bot else 0
    _send("status_reply", id=msg_id, bot_name=name, guild_count=guilds)


def _on_shutdown(msg: dict) -> None:
    bot  = _state.get("bot")
    loop = getattr(bot, "loop", None) if bot else None
    if bot and loop and loop.is_running():
        asyncio.run_coroutine_threadsafe(bot.close(), loop)
    else:
        sys.exit(0)


_DISPATCH = {
    "reload_cog": _on_reload_cog,
    "ping":       _on_ping,
    "status":     _on_status,
    "shutdown":   _on_shutdown,
}


# ── IPC receiver thread ───────────────────────────────────────────────────────
def _recv_loop() -> None:
    buf = ""
    while _state["running"]:
        sock = _state.get("sock")
        if not sock:
            time.sleep(_RECONNECT_DELAY)
            _connect()
            continue
        try:
            sock.settimeout(1.0)
            chunk = sock.recv(4096).decode("utf-8", errors="replace")
            if not chunk:
                _log("HIBM disconnected — will reconnect ...")
                _state["sock"] = None
                continue
            buf += chunk
            while "\n" in buf:
                line, buf = buf.split("\n", 1)
                line = line.strip()
                if line:
                    try:
                        msg = json.loads(line)
                        handler = _DISPATCH.get(msg.get("type"))
                        if handler:
                            handler(msg)
                    except Exception as exc:
                        _err(f"Bad message: {exc}")
        except socket.timeout:
            continue
        except Exception as exc:
            _err(f"Recv error: {exc}")
            _state["sock"] = None


# ── Heartbeat thread ──────────────────────────────────────────────────────────
def _heartbeat_loop() -> None:
    while _state["running"]:
        time.sleep(_HB_INTERVAL)
        _send("heartbeat", timestamp=int(time.time()))


# ── discord.Bot monkey-patch ──────────────────────────────────────────────────
def _patch_discord() -> None:
    """
    Patch discord.ext.commands.Bot and discord.Client so we capture
    the bot instance immediately when it is constructed.
    """
    try:
        import discord
        import discord.ext.commands as _cmds
    except ImportError:
        # discord.py not imported yet — will retry via import hook below
        return

    _apply_patches(_cmds, discord)


def _apply_patches(cmds_module, discord_module) -> None:
    """Apply __init__ patches to Bot, AutoShardedBot, Client."""

    for cls_name in ("Bot", "AutoShardedBot"):
        cls = getattr(cmds_module, cls_name, None)
        if cls is None:
            continue
        if getattr(cls, "_hibm_patched", False):
            continue

        _orig = cls.__init__

        def _make_patched(original_init, class_name):
            def _patched_init(self, *args, **kwargs):
                original_init(self, *args, **kwargs)
                if _state["bot"] is None:
                    _state["bot"] = self
                    _log(f"{class_name} instance captured")
                    # Hook on_ready to announce ourselves
                    _hook_ready(self)
            return _patched_init

        cls.__init__  = _make_patched(_orig, cls_name)
        cls._hibm_patched = True


def _hook_ready(bot) -> None:
    """Register an on_ready listener to send READY to HIBM once bot logs in."""
    try:
        async def _on_ready_cb():
            bot_name   = str(getattr(bot, "user", "?"))
            guild_count = len(getattr(bot, "guilds", []))
            _send("ready", bot_name=bot_name, guild_count=guild_count)
            _state["ready"] = True

        bot.add_listener(_on_ready_cb, "on_ready")
    except Exception as exc:
        _err(f"Could not hook on_ready: {exc}")


# ── Import hook — ensures we patch even if discord is imported AFTER us ───────
class _DiscordImportHook:
    """sys.meta_path hook that intercepts the first import of discord."""

    def find_module(self, name, path=None):
        if name == "discord" or name.startswith("discord."):
            return self
        return None

    def load_module(self, name):
        # Remove ourselves so normal import proceeds
        if self in sys.meta_path:
            sys.meta_path.remove(self)
        # Normal import
        import importlib
        mod = importlib.import_module(name)
        # Now try to patch
        try:
            import discord
            import discord.ext.commands as _cmds
            _apply_patches(_cmds, discord)
        except Exception:
            pass
        return mod


# ── Bootstrap ─────────────────────────────────────────────────────────────────
def _bootstrap() -> None:
    if _IPC_PORT:
        _connect()

    # Try immediate patch (if discord already imported by the time wrapper runs)
    _patch_discord()

    # Install import hook for bots that import discord after our exec()
    sys.meta_path.insert(0, _DiscordImportHook())

    # Start daemon threads
    threading.Thread(target=_recv_loop,      name="hibm-recv",      daemon=True).start()
    threading.Thread(target=_heartbeat_loop, name="hibm-heartbeat", daemon=True).start()

    _log("HIBM IPC wrapper active")


_bootstrap()
