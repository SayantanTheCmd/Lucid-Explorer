"""
runtime/utils/logger.py
Centralised logging for HIBM.

Features:
  - Writes timestamped entries to a log file (with rotation)
  - Mirrors output to stdout with ANSI colour coding
  - Single get_logger() factory so every module shares the same formatter
  - Pterodactyl-safe: only uses standard-library ANSI codes, no curses/rich
"""

import logging
import os
import sys
from logging.handlers import RotatingFileHandler

from runtime.constants.paths    import LOG_RUNTIME, LOGS_DIR
from runtime.constants.defaults import LOG_LEVEL, LOG_MAX_BYTES, LOG_BACKUP_COUNT

# ── ANSI colour helpers ───────────────────────────────────────────────────────
_RESET  = "\033[0m"
_BOLD   = "\033[1m"
_COLORS = {
    "DEBUG"    : "\033[36m",   # Cyan
    "INFO"     : "\033[32m",   # Green
    "WARNING"  : "\033[33m",   # Yellow
    "ERROR"    : "\033[31m",   # Red
    "CRITICAL" : "\033[35m",   # Magenta
}


class _ColourFormatter(logging.Formatter):
    """Formatter that adds ANSI colour to the level name on stdout."""

    FMT = "[{asctime}] [{levelname:<8}] {name}: {message}"
    DATEFMT = "%H:%M:%S"

    def format(self, record: logging.LogRecord) -> str:
        colour = _COLORS.get(record.levelname, "")
        record.levelname = f"{colour}{_BOLD}{record.levelname}{_RESET}"
        formatter = logging.Formatter(self.FMT, datefmt=self.DATEFMT, style="{")
        return formatter.format(record)


class _PlainFormatter(logging.Formatter):
    """Plain formatter for file output (no ANSI codes)."""

    FMT    = "[{asctime}] [{levelname:<8}] {name}: {message}"
    DATEFMT = "%Y-%m-%d %H:%M:%S"

    def __init__(self):
        super().__init__(self.FMT, datefmt=self.DATEFMT, style="{")


# ── Internal registry ─────────────────────────────────────────────────────────
_loggers: dict[str, logging.Logger] = {}
_root_configured = False


def _configure_root() -> None:
    """One-time setup: attach a RotatingFileHandler + StreamHandler to root."""
    global _root_configured
    if _root_configured:
        return

    os.makedirs(LOGS_DIR, exist_ok=True)

    root = logging.getLogger("hibm")
    root.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

    # File handler — plain text, rotating
    fh = RotatingFileHandler(
        LOG_RUNTIME,
        maxBytes=LOG_MAX_BYTES,
        backupCount=LOG_BACKUP_COUNT,
        encoding="utf-8",
    )
    fh.setFormatter(_PlainFormatter())
    root.addHandler(fh)

    # Stream handler — coloured stdout
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(_ColourFormatter())
    root.addHandler(sh)

    root.propagate = False
    _root_configured = True


def get_logger(name: str) -> logging.Logger:
    """
    Return a named child of the 'hibm' root logger.

    Usage:
        log = get_logger(__name__)
        log.info("Hello from %s", __name__)
    """
    _configure_root()
    if name not in _loggers:
        logger = logging.getLogger(f"hibm.{name}")
        _loggers[name] = logger
    return _loggers[name]


# ── Convenience print wrappers (used by UI layer for raw output) ──────────────
def print_ok(msg: str) -> None:
    """Print a success-coloured line directly to stdout."""
    print(f"  \033[92m\033[1m✔\033[0m  {msg}")


def print_warn(msg: str) -> None:
    print(f"  \033[93m\033[1m⚠\033[0m  {msg}")


def print_err(msg: str) -> None:
    print(f"  \033[91m\033[1m✖\033[0m  {msg}")


def print_info(msg: str) -> None:
    print(f"  \033[96m\033[1m◈\033[0m  {msg}")


def print_step(step: int, total: int, msg: str) -> None:
    print(f"  \033[97m\033[1m[{step}/{total}]\033[0m  {msg}")
