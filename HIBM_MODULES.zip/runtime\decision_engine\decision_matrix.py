# Decision logic is in strategies.py
