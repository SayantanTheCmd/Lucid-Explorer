"""
runtime/updater/clone.py
Git clone engine with optional token injection and real-time progress display.

git writes all progress to stderr using carriage-return (\r) to overwrite
the same line. We stream it character-by-character via Popen so the user
sees live progress: "Receiving objects:  67% (1234/1841)  2.3 MiB/s"

Returns a CloneResult dataclass describing what happened so callers
can react without parsing raw stderr.
"""

import os
import sys
import subprocess
from dataclasses import dataclass
from typing import Optional

from runtime.constants.enums        import CloneStatus
from runtime.constants.paths        import REPOSITORIES
from runtime.utils.logger           import get_logger, print_ok, print_err, print_info
from runtime.utils.filesystem       import ensure_dir, dir_is_empty, repo_name_from_url
from runtime.utils.helpers          import inject_token_into_url, normalise_url
from runtime.updater.commit_tracker import store_sha

log = get_logger(__name__)

# Lines in git stderr that are real progress (not errors)
_PROGRESS_PREFIXES = (
    "Cloning into",
    "remote: Counting",
    "remote: Compressing",
    "remote: Total",
    "Receiving objects",
    "Resolving deltas",
    "Updating files",
    "remote: Enumerating",
)


@dataclass
class CloneResult:
    status:    CloneStatus
    repo_name: str = ""
    repo_path: str = ""
    error_msg: str = ""


# ── Public API ────────────────────────────────────────────────────────────────

def clone(url: str, token: Optional[str] = None) -> CloneResult:
    """
    Clone a git repository into HIBM/repositories/<repo_name>/.

    Args:
        url:   The git repository URL (HTTPS or SSH).
        token: Optional personal access token for private repos.

    Returns:
        CloneResult with status, local path, and any error info.
    """
    url       = normalise_url(url)
    repo_name = repo_name_from_url(url)
    repo_path = os.path.join(REPOSITORIES, repo_name)

    log.info("Cloning repository '%s' to %s", repo_name, repo_path)

    # ── Already cloned? ───────────────────────────────────────────────────────
    if os.path.isdir(repo_path) and not dir_is_empty(repo_path):
        if os.path.isdir(os.path.join(repo_path, ".git")):
            print_info(f"Repository '{repo_name}' already exists locally — skipping clone.")
            log.info("[%s] Already cloned at %s", repo_name, repo_path)
            _capture_current_sha(repo_name, repo_path)
            return CloneResult(
                status=CloneStatus.ALREADY_EXISTS,
                repo_name=repo_name,
                repo_path=repo_path,
            )

    ensure_dir(repo_path)

    # ── Build effective clone URL ─────────────────────────────────────────────
    effective_url = inject_token_into_url(url, token) if token else url
    cmd = ["git", "clone", "--progress", effective_url, repo_path]

    print_info(f"Source : {url}")
    print()

    # ── Run git clone with live progress streaming ────────────────────────────
    stderr_lines: list[str] = []

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=0,          # Unbuffered — essential for live progress
        )
    except FileNotFoundError:
        msg = "git not found — install git and add it to PATH."
        print_err(msg)
        log.critical(msg)
        return CloneResult(status=CloneStatus.ERROR, repo_name=repo_name, error_msg=msg)

    # ── Stream stderr in real time ────────────────────────────────────────────
    # git sends progress on stderr using \r to overwrite the current line and
    # \n when a phase completes. We buffer char-by-char and flush on \r or \n.
    _stream_git_stderr(proc.stderr, stderr_lines)

    proc.wait()                          # Ensure process has fully exited
    stdout_out = proc.stdout.read().strip()
    print()                              # Final newline after progress block

    # ── Evaluate result ───────────────────────────────────────────────────────
    if proc.returncode == 0:
        print_ok(f"Cloned '{repo_name}' successfully.")
        log.info("[%s] Clone succeeded", repo_name)
        _capture_current_sha(repo_name, repo_path)
        return CloneResult(
            status=CloneStatus.SUCCESS,
            repo_name=repo_name,
            repo_path=repo_path,
        )

    # ── Parse failure reason from collected stderr ────────────────────────────
    combined = " ".join(stderr_lines).lower() + stdout_out.lower()

    if "authentication failed" in combined or "invalid username or password" in combined:
        status   = CloneStatus.AUTH_FAILED
        friendly = "Authentication failed — check your token or URL."
    elif "repository not found" in combined or "not found" in combined:
        status   = CloneStatus.NOT_FOUND
        friendly = f"Repository not found: {url}"
    else:
        # Surface the last meaningful error line
        error_line = next(
            (l for l in reversed(stderr_lines) if l.strip() and not _is_progress(l)),
            stdout_out or "Unknown git error.",
        )
        status   = CloneStatus.ERROR
        friendly = error_line.strip()

    print()
    print_err(friendly)
    log.error("[%s] Clone failed (%s): %s", repo_name, status.name, friendly)

    return CloneResult(
        status=status,
        repo_name=repo_name,
        repo_path=repo_path,
        error_msg=friendly,
    )


# ── Internal helpers ──────────────────────────────────────────────────────────

def _stream_git_stderr(pipe, collected: list) -> None:
    """
    Read git's stderr and render a styled progress bar identical to the
    download bar: [████████░░░░] 67%  (1234/1841)  phase label

    git progress lines look like:
      Receiving objects:  45% (450/1000), 1.23 MiB | 2.50 MiB/s
      Resolving deltas:  100% (200/200), done.
    Completion lines end with ", done." and use \\n.
    In-progress lines use \\r to overwrite.
    """
    import re
    buf = []
    _phase_order = [
        "Counting",
        "Enumerating",
        "Compressing",
        "Total",
        "Receiving",
        "Resolving",
        "Updating",
    ]

    def _render(line: str) -> None:
        # Try to extract percentage and counts from git progress lines
        pct_match   = re.search(r"(\d+)%", line)
        count_match = re.search(r"\((\d+)/(\d+)\)", line)

        # Determine phase label (first matching keyword)
        phase = ""
        for kw in _phase_order:
            if kw.lower() in line.lower():
                phase = kw
                break

        if pct_match:
            pct = int(pct_match.group(1))
            bar_len = 28
            filled  = int(bar_len * pct / 100)
            bar     = "█" * filled + "░" * (bar_len - filled)

            count_str = ""
            if count_match:
                count_str = f"  ({count_match.group(1)}/{count_match.group(2)})"

            label = phase if phase else "Cloning"
            sys.stdout.write(f"\r  [{bar}] {pct:3d}%{count_str}  {label:<12}")
            sys.stdout.flush()
        else:
            # Non-progress line: just print it
            clean = line.strip()
            if clean:
                sys.stdout.write(f"\r  {clean:<72}\n")
                sys.stdout.flush()

    def _done(line: str) -> None:
        """Print a completed-phase tick."""
        phase = ""
        for kw in _phase_order:
            if kw.lower() in line.lower():
                phase = kw
                break
        label = phase if phase else "Step"
        bar   = "█" * 28
        sys.stdout.write(f"\r  [{bar}] 100%  {label:<12}  ✔\n")
        sys.stdout.flush()

    try:
        while True:
            ch = pipe.read(1)
            if not ch:
                break

            if ch == "\r":
                line = "".join(buf).rstrip()
                buf.clear()
                if line:
                    collected.append(line)
                    _render(line)

            elif ch == "\n":
                line = "".join(buf).rstrip()
                buf.clear()
                if line:
                    collected.append(line)
                    # git prints ", done." on the final newline-terminated line
                    if "done." in line.lower() or "done" in line.lower():
                        _done(line)
                    elif _is_progress(line):
                        _render(line)
                    else:
                        # Non-progress info line (e.g. "Cloning into '...'")
                        clean = line.strip()
                        if clean:
                            sys.stdout.write(f"\r  {clean:<72}\n")
                            sys.stdout.flush()
            else:
                buf.append(ch)

        # Flush remaining buffer
        if buf:
            line = "".join(buf).rstrip()
            if line:
                collected.append(line)
                sys.stdout.write(f"\r  {line:<72}\n")
                sys.stdout.flush()

    except Exception as exc:
        import logging
        logging.getLogger(__name__).debug("stderr stream error: %s", exc)


def _is_progress(line: str) -> bool:
    """Return True if the line is a git progress line (not an error)."""
    return any(line.strip().startswith(p) for p in _PROGRESS_PREFIXES)


def _capture_current_sha(repo_name: str, repo_path: str) -> None:
    """Store the current HEAD SHA immediately after a successful clone."""
    try:
        proc = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10,
        )
        if proc.returncode == 0:
            sha = proc.stdout.strip()
            store_sha(repo_name, sha)
            log.debug("[%s] Initial SHA captured: %s", repo_name, sha[:7])
    except Exception as exc:
        log.debug("[%s] Could not capture initial SHA: %s", repo_name, exc)
