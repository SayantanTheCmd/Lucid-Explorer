"""
unloader/unloader.py
════════════════════════════════════════════════════════════════
HIBM Pre-installed Package Unloader

Responsibilities:
  1. Check if preinstalled.zip exists in this directory
  2. Check if cache/packages/ is already populated (idempotent)
  3. Extract preinstalled.zip → cache/packages/
  4. Inject cache/packages/ into sys.path[0] so Python finds them
  5. Return a PreloadResult so the launcher knows what's available
     and can skip pip for those packages

Platform note:
  uvloop is Linux/macOS only. If running on Windows and the zip
  contains uvloop, it is silently skipped during extraction.

Run order:
  This module must be imported and called BEFORE any other HIBM
  runtime imports, immediately after sys.path is patched in Startall.py.
════════════════════════════════════════════════════════════════
"""

import os
import sys
import zipfile
import platform
from dataclasses import dataclass, field

# ── Terminal setup (must happen before any print) ──────────────────────────────
# 1. Force UTF-8 so Unicode box chars don't crash on cp1252
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# 2. Enable Windows Virtual Terminal Processing so ANSI codes show as colors.
#    This is an inline ctypes call so unloader has zero external deps.
if sys.platform == "win32":
    try:
        import ctypes, ctypes.wintypes as _wt
        _k32 = ctypes.windll.kernel32
        _ENABLE_VTP = 0x0004
        for _std in (-11, -12):  # STD_OUTPUT_HANDLE, STD_ERROR_HANDLE
            _h = _k32.GetStdHandle(_std)
            _m = _wt.DWORD()
            if _k32.GetConsoleMode(_h, ctypes.byref(_m)):
                _k32.SetConsoleMode(_h, _m.value | _ENABLE_VTP)
    except Exception:
        pass

# ── Path resolution (standalone — no runtime imports yet) ────────────────────
_UNLOADER_DIR    = os.path.dirname(os.path.abspath(__file__))
_HIBM_ROOT       = os.path.dirname(_UNLOADER_DIR)
_CACHE_PACKAGES  = os.path.join(_HIBM_ROOT, "cache", "packages")
_PREINSTALLED_ZIP = os.path.join(_UNLOADER_DIR, "preinstalled.zip")
_STAMP_FILE      = os.path.join(_CACHE_PACKAGES, ".unloaded")      # Presence = already extracted
_CLEANUP_MARKER  = os.path.join(_CACHE_PACKAGES, ".pending_cleanup") # Written on shutdown

# Packages that must NOT be extracted on Windows
_WINDOWS_SKIP = {"uvloop"}

# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PreloadResult:
    """Result of calling unload()."""
    success: bool
    packages_path: str                  # Path added to sys.path
    available_names: set[str] = field(default_factory=set)  # Normalised pkg names
    skipped_names: set[str]   = field(default_factory=set)  # Platform-skipped
    extracted_count: int = 0
    already_cached: bool = False
    zip_missing: bool    = False
    error: str           = ""


def unload(verbose: bool = True) -> PreloadResult:
    """
    Extract preinstalled.zip into cache/packages/ and patch sys.path.

    Args:
        verbose: Print progress to stdout (Pterodactyl-safe plain print).

    Returns:
        PreloadResult describing what was loaded.
    """
    result = PreloadResult(success=False, packages_path=_CACHE_PACKAGES)

    # ── Guard: zip exists? If not, download it automatically ─────────────────
    if not os.path.isfile(_PREINSTALLED_ZIP):
        result.zip_missing = True
        if verbose:
            _info("preinstalled.zip not found — downloading from GitHub ...")
            _info("(This happens on first run or after a clean shutdown.)")
            print()

        # Lazy import downloader (stdlib only, safe before packages are extracted)
        try:
            from unloader import downloader as _dl
        except ImportError:
            import importlib.util as _ilu
            _spec = _ilu.spec_from_file_location(
                "downloader",
                os.path.join(_UNLOADER_DIR, "downloader.py"),
            )
            _dl = _ilu.module_from_spec(_spec)
            _spec.loader.exec_module(_dl)

        dl_ok = _dl.download(_PREINSTALLED_ZIP)
        if not dl_ok:
            result.error = (
                "Failed to download preinstalled.zip from GitHub.\n"
                "  Check your internet connection and try again."
            )
            if verbose:
                _err(result.error)
            return result

        result.zip_missing = False   # download succeeded
        if verbose:
            print()


    # ── Pending cleanup from previous shutdown ───────────────────────────────
    # The previous run wrote .pending_cleanup because Windows locks .pyd files
    # while they are loaded. Now (before sys.path is patched = before any .pyd
    # is loaded) we can safely wipe the whole directory.
    if os.path.isdir(_CACHE_PACKAGES) and os.path.isfile(_CLEANUP_MARKER):
        if verbose:
            _info("Performing deferred cleanup from previous shutdown ...")
        try:
            import shutil as _shutil
            _shutil.rmtree(_CACHE_PACKAGES)
            if verbose:
                _ok("cache/packages/ wiped — will re-extract now.")
        except Exception as _e:
            if verbose:
                _warn(f"Deferred cleanup failed: {_e}")

    os.makedirs(_CACHE_PACKAGES, exist_ok=True)

    # ── Guard: already extracted? (check stamp file) ──────────────────────────
    if os.path.isfile(_STAMP_FILE):
        result.already_cached = True
        result.success = True
        result.available_names = _scan_available()
        if verbose:
            _ok(f"Pre-installed packages already loaded ({len(result.available_names)} packages)")
        _patch_syspath()
        return result

    # ── Extract ───────────────────────────────────────────────────────────────
    is_windows = platform.system().lower() == "windows"
    skipped    = set()
    extracted  = 0

    if verbose:
        sys.stdout.write(f"  \033[32m│\033[0m  \033[96m\033[1m◈\033[0m  Extracting packages... ")
        sys.stdout.flush()

    try:
        with zipfile.ZipFile(_PREINSTALLED_ZIP, "r") as zf:
            members = zf.namelist()
            for member in members:
                # Check if this member belongs to a platform-skipped package
                top = member.split("/")[0].lower().replace("-", "_")
                if is_windows and any(skip in top for skip in _WINDOWS_SKIP):
                    skipped.add(top)
                    continue

                zf.extract(member, _CACHE_PACKAGES)
                extracted += 1

    except zipfile.BadZipFile as exc:
        result.error = f"preinstalled.zip is corrupted: {exc}"
        if verbose:
            sys.stdout.write(f"\n  \033[32m│\033[0m  \033[91m\033[1m✖\033[0m  {result.error}\n")
        return result
    except Exception as exc:
        result.error = f"Extraction failed: {exc}"
        if verbose:
            sys.stdout.write(f"\n  \033[32m│\033[0m  \033[91m\033[1m✖\033[0m  {result.error}\n")
        return result

    # ── Write stamp ───────────────────────────────────────────────────────────
    try:
        with open(_STAMP_FILE, "w") as f:
            f.write(f"extracted={extracted}\nplatform={platform.system()}\n")
    except OSError:
        pass  # Non-fatal

    result.extracted_count = extracted
    result.skipped_names   = skipped
    result.success         = True
    result.available_names = _scan_available()

    if verbose:
        sys.stdout.write(f"\r  \033[92m\033[1m✔\033[0m  Extracted packages — {len(result.available_names)} package(s) available                   \n")
        sys.stdout.flush()
        if skipped:
            _info(f"Platform-skipped: {', '.join(skipped)}")

    _patch_syspath()
    return result


def _patch_syspath() -> None:
    """Prepend cache/packages/ to sys.path so imports resolve immediately."""
    if _CACHE_PACKAGES not in sys.path:
        sys.path.insert(0, _CACHE_PACKAGES)


def _scan_available() -> set[str]:
    """
    Scan cache/packages/ for installed dist-info directories and return
    a normalised set of package names for O(1) lookup.

    e.g.  discord.py-2.3.2.dist-info  →  "discord_py"
    """
    names: set[str] = set()
    if not os.path.isdir(_CACHE_PACKAGES):
        return names

    for entry in os.listdir(_CACHE_PACKAGES):
        if entry.endswith(".dist-info"):
            # entry format: PackageName-version.dist-info
            pkg_raw = entry.split("-")[0]
            names.add(pkg_raw.lower().replace("-", "_"))
        elif entry.endswith(".egg-info"):
            pkg_raw = entry.split(".egg-info")[0]
            names.add(pkg_raw.lower().replace("-", "_"))

    return names


def get_available_packages() -> set[str]:
    """
    Convenience: return the set of normalised names available in cache/packages/.
    Call after unload() has been called.
    """
    return _scan_available()


def clear_cache() -> None:
    """
    Delete the stamp file so the next startup re-extracts the zip.
    Useful after rebuilding preinstalled.zip.
    """
    if os.path.isfile(_STAMP_FILE):
        os.remove(_STAMP_FILE)
        print("  [unloader] Cache stamp cleared — will re-extract on next start.")


# ── Minimal CLI-style print helpers (no runtime.utils dependency) ────────────────────
def _ok(msg: str)   -> None: print(f"  \033[32m│\033[0m  \033[92m\033[1m✔\033[0m  {msg}")
def _info(msg: str) -> None: print(f"  \033[32m│\033[0m  \033[96m\033[1m◈\033[0m  {msg}")
def _warn(msg: str) -> None: print(f"  \033[32m│\033[0m  \033[93m\033[1m⚠\033[0m  {msg}")
def _err(msg: str)  -> None: print(f"  \033[32m│\033[0m  \033[91m\033[1m✖\033[0m  {msg}")
