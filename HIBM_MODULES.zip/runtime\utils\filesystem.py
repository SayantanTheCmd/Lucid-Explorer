"""
runtime/utils/filesystem.py
Safe filesystem helpers used throughout the runtime.
"""

import os
import shutil
from typing import Optional

from runtime.utils.logger import get_logger

log = get_logger(__name__)


def ensure_dir(path: str) -> str:
    """Create directory (and parents) if it doesn't exist. Returns the path."""
    os.makedirs(path, exist_ok=True)
    return path


def ensure_dirs(*paths: str) -> None:
    """Create multiple directories, ignoring already-existing ones."""
    for p in paths:
        ensure_dir(p)


def safe_remove(path: str) -> bool:
    """
    Remove a file or directory tree safely.
    Returns True on success, False if the path did not exist.
    """
    if not os.path.exists(path):
        return False
    try:
        if os.path.isdir(path):
            shutil.rmtree(path)
        else:
            os.remove(path)
        return True
    except OSError as exc:
        log.error("Could not remove %s: %s", path, exc)
        return False


def read_text(path: str, encoding: str = "utf-8") -> Optional[str]:
    """Read a text file, returning None if it doesn't exist or can't be read."""
    try:
        with open(path, "r", encoding=encoding) as f:
            return f.read()
    except (OSError, UnicodeDecodeError) as exc:
        log.debug("Could not read %s: %s", path, exc)
        return None


def write_text(path: str, content: str, encoding: str = "utf-8") -> bool:
    """Write a string to a file, creating parent dirs as needed."""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding=encoding) as f:
            f.write(content)
        return True
    except OSError as exc:
        log.error("Could not write %s: %s", path, exc)
        return False


def find_file(root: str, filename: str) -> Optional[str]:
    """
    Recursively search for the first file named `filename` under `root`.
    Returns the absolute path if found, else None.
    """
    for dirpath, _dirs, files in os.walk(root):
        if filename in files:
            return os.path.join(dirpath, filename)
    return None


def find_files_by_extension(root: str, ext: str) -> list[str]:
    """
    Recursively find all files with a given extension under `root`.
    `ext` should include the dot, e.g. '.py'.
    """
    results = []
    for dirpath, _dirs, files in os.walk(root):
        for fname in files:
            if fname.endswith(ext):
                results.append(os.path.join(dirpath, fname))
    return results


def dir_is_empty(path: str) -> bool:
    """Return True if the directory exists and contains no children."""
    if not os.path.isdir(path):
        return True
    return len(os.listdir(path)) == 0


def repo_name_from_url(url: str) -> str:
    """
    Extract a filesystem-safe repository folder name from a git URL.

    Examples:
        https://github.com/user/my-bot.git  →  my-bot
        git@github.com:user/my-bot.git      →  my-bot
    """
    url = url.rstrip("/")
    if url.endswith(".git"):
        url = url[:-4]
    name = url.split("/")[-1]
    # Strip any colon-prefixed user (SSH format)
    if ":" in name:
        name = name.split(":")[-1]
    # Sanitise to alphanumeric, dash, underscore, dot
    sanitised = "".join(c if c.isalnum() or c in "-_." else "_" for c in name)
    return sanitised or "unknown_repo"
