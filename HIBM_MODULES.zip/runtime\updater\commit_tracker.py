"""
runtime/updater/commit_tracker.py
Persist and recall the last-known git commit SHA for each repository.

SHAs are stored as plain text files under:
    cache/commits/<repo_name>.sha
"""

import os

from runtime.constants.paths  import CACHE_COMMITS
from runtime.utils.logger     import get_logger
from runtime.utils.filesystem import ensure_dir, read_text, write_text

log = get_logger(__name__)


def _sha_path(repo_name: str) -> str:
    ensure_dir(CACHE_COMMITS)
    return os.path.join(CACHE_COMMITS, f"{repo_name}.sha")


def get_stored_sha(repo_name: str) -> str | None:
    """Return the last stored commit SHA for `repo_name`, or None."""
    content = read_text(_sha_path(repo_name))
    if content:
        return content.strip() or None
    return None


def store_sha(repo_name: str, sha: str) -> None:
    """Persist a commit SHA to disk."""
    write_text(_sha_path(repo_name), sha.strip())
    log.debug("[%s] Stored commit SHA: %s", repo_name, sha[:7])


def clear_sha(repo_name: str) -> None:
    """Remove the stored SHA (e.g. after a forced re-clone)."""
    path = _sha_path(repo_name)
    if os.path.exists(path):
        os.remove(path)
        log.debug("[%s] Cleared stored SHA", repo_name)
