# Reserved for future multi-bot process registry
