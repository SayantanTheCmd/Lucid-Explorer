# Heartbeat sent from _hibm_wrapper.py inside bot process
