"""
runtime/utils/ansi.py
──────────────────────────────────────────────────────────────────────────
ANSI color support bootstrap for HIBM.

Call enable() as the very FIRST thing in any entry-point before any
colored output is printed. It handles three situations:

  1. Windows Console Host (cmd / PowerShell)
     → Enables ENABLE_VIRTUAL_TERMINAL_PROCESSING via ctypes so that
       \033[32m etc. are rendered as real colors, not literal text.

  2. Dumb / piped terminal (no TTY, CI, redirected output)
     → Sets NO_COLOR mode: all ANSI codes are stripped before printing
       so logs stay readable without garbage characters.

  3. Unix / Linux / macOS / Pterodactyl xterm.js
     → ANSI works natively — nothing to do.

After calling enable(), import `ANSI_OK` to know whether colors are live.
──────────────────────────────────────────────────────────────────────────
"""

import os
import sys

# Public flag — True if ANSI escape codes will render correctly
ANSI_OK: bool = False


def enable() -> bool:
    """
    Attempt to enable ANSI color support for the current terminal.

    Returns:
        True if ANSI codes will render correctly, False if they were disabled.
    """
    global ANSI_OK

    # ── Respect explicit NO_COLOR env var (https://no-color.org) ─────────────
    if os.environ.get("NO_COLOR") or os.environ.get("HIBM_NO_COLOR"):
        _patch_stdout_strip()
        ANSI_OK = False
        return False

    # ── Non-TTY (piped / redirected / Pterodactyl raw stdin mode) ─────────────
    # sys.stdout.isatty() returns False when output is piped to a file or
    # certain terminal emulators that don't declare TTY support.
    # In that case strip ANSI so the output is clean plain text.
    if not _is_tty():
        _patch_stdout_strip()
        ANSI_OK = False
        return False

    # ── Windows: enable Virtual Terminal Processing ────────────────────────────
    if sys.platform == "win32":
        if _enable_windows_vtp():
            ANSI_OK = True
        else:
            # VTP failed — strip colors rather than show garbage
            _patch_stdout_strip()
            ANSI_OK = False
        return ANSI_OK

    # ── Unix / macOS / Linux — ANSI works natively ────────────────────────────
    ANSI_OK = True
    return True


# ── Windows VTP ───────────────────────────────────────────────────────────────

def _enable_windows_vtp() -> bool:
    """
    Enable ENABLE_VIRTUAL_TERMINAL_PROCESSING on Windows stdout and stderr
    so ANSI escape codes are interpreted by conhost / Windows Terminal.

    Available on Windows 10 build 1511 (TH2) and later.
    Returns True if successful.
    """
    try:
        import ctypes
        import ctypes.wintypes as wt

        kernel32 = ctypes.windll.kernel32

        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        STD_OUTPUT_HANDLE = -11
        STD_ERROR_HANDLE  = -12

        def _set_vtp(std_handle: int) -> bool:
            handle = kernel32.GetStdHandle(std_handle)
            if handle == wt.HANDLE(-1).value:
                return False
            mode = wt.DWORD()
            if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                return False
            new_mode = mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING
            return bool(kernel32.SetConsoleMode(handle, new_mode))

        out_ok = _set_vtp(STD_OUTPUT_HANDLE)
        _set_vtp(STD_ERROR_HANDLE)   # best-effort for stderr
        return out_ok

    except Exception:
        return False


# ── Strip-ANSI stdout patch ───────────────────────────────────────────────────

class _StripAnsiWriter:
    """Wraps sys.stdout and strips ANSI escape codes before writing."""

    import re as _re
    _ANSI = _re.compile(r"\033\[[0-9;]*[mK]")

    def __init__(self, wrapped):
        self._wrapped = wrapped

    def write(self, text: str) -> int:
        clean = self._ANSI.sub("", text)
        return self._wrapped.write(clean)

    def flush(self):
        self._wrapped.flush()

    def __getattr__(self, name):
        return getattr(self._wrapped, name)


def _patch_stdout_strip() -> None:
    """Replace sys.stdout with a writer that strips ANSI codes."""
    if not isinstance(sys.stdout, _StripAnsiWriter):
        sys.stdout = _StripAnsiWriter(sys.stdout)


# ── Convenience: is this a real interactive terminal? ────────────────────────

def _is_tty() -> bool:
    try:
        return sys.stdout.isatty()
    except Exception:
        return False
