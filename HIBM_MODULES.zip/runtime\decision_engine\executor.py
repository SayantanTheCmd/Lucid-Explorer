"""
runtime/decision_engine/executor.py
Carries out the Action decided by strategies.decide().

Three action paths:

  PULL_ONLY   → git pull, bot process untouched
  HOT_RELOAD  → git pull → send reload_cog to each changed cog via IPC
  HOT_RESTART → git pull → [pip install] → stop bot → start bot
"""

import subprocess
import time
from typing import Optional, TYPE_CHECKING

from runtime.decision_engine.analyzer  import DiffResult
from runtime.decision_engine.strategies import Action
from runtime.ipc.protocol              import Msg, MsgType
from runtime.utils.logger              import get_logger, print_ok, print_info, print_warn, print_err

if TYPE_CHECKING:
    from runtime.ipc.server      import IPCServer
    from runtime.process.manager import BotProcess

log = get_logger(__name__)


# ── Public API ────────────────────────────────────────────────────────────────

def execute(
    action:      Action,
    diff:        DiffResult,
    bot:         "BotProcess",
    ipc:         "IPCServer",
    repo_path:   str,
    scan_result = None,   # ScanResult — used for pip re-install
) -> None:
    """
    Execute the chosen action.

    Args:
        action:      Result of strategies.decide(diff)
        diff:        The analyzed diff
        bot:         Running BotProcess handle (for restart)
        ipc:         HIBM IPC server (for hot reload commands)
        repo_path:   Absolute path to the bot repository
        scan_result: Original ScanResult (requirements path, etc.)
    """
    log.info("[Executor] %s  (%s→%s)", action.value, diff.old_sha[:7], diff.new_sha[:7])

    if action == Action.NONE:
        return

    if action == Action.PULL_ONLY:
        _pull_only(repo_path, diff)

    elif action == Action.HOT_RELOAD:
        _hot_reload(repo_path, diff, ipc, bot, scan_result)

    elif action == Action.HOT_RESTART:
        _hot_restart(repo_path, diff, bot, ipc, scan_result)



# ── Action implementations ─────────────────────────────────────────────────────

def _pull_only(repo_path: str, diff: DiffResult) -> None:
    """git pull — bot process untouched."""
    print_info(f"[Update] Pull-only  ({diff.old_sha[:7]}→{diff.new_sha[:7]})")
    if git_pull(repo_path):
        print_ok("[Update] Pulled static changes. Bot is still running.")
    else:
        print_err("[Update] git pull failed — will retry next cycle.")


def _hot_reload(
    repo_path:   str,
    diff:        DiffResult,
    ipc:         "IPCServer",
    bot:         "BotProcess",
    scan_result = None,
) -> None:
    """git pull → reload each changed cog via IPC (no bot restart)."""
    n = len(diff.modified_cogs)
    print_info(f"[Update] Hot Reload  — {n} cog(s)  ({diff.old_sha[:7]}→{diff.new_sha[:7]})")

    if not git_pull(repo_path):
        print_err("[Update] git pull failed — skipping hot reload.")
        return

    # If IPC is not available fall back to hot restart so code is not stale
    if not ipc.connected:
        print_warn("[Update] IPC not connected — falling back to Hot Restart.")
        _hot_restart(repo_path, diff, bot, ipc, scan_result)
        return


    ok = 0
    fail = 0
    for cog in diff.modified_cogs:
        msg   = Msg(type=MsgType.RELOAD_COG, data={"cog": cog})
        reply = ipc.request(msg, timeout=12.0)

        if reply and reply.data.get("ok"):
            print_ok(f"[Update]   Hot reloaded: {cog}")
            ok += 1
        else:
            err = (reply.data.get("error", "?") if reply else "timeout")
            print_err(f"[Update]   Reload failed: {cog}  ({err})")
            fail += 1

    if fail == 0:
        print_ok(f"[Update] Hot reload complete — all {ok} cog(s) live.")
    else:
        print_warn(
            f"[Update] Hot reload partial — {ok} ok, {fail} failed. "
            "Bot is running with partially old code."
        )


def _hot_restart(
    repo_path:   str,
    diff:        DiffResult,
    bot:         "BotProcess",
    ipc:         "IPCServer",
    scan_result,
) -> None:
    """git pull → [pip install] → stop → start."""
    # Build a clear reason string
    reasons = []
    if diff.main_changed:          reasons.append("main.py")
    if diff.requirements_changed:  reasons.append("requirements.txt")
    if diff.added_cogs:            reasons.append(f"+{len(diff.added_cogs)} cog(s)")
    if diff.deleted_cogs:          reasons.append(f"-{len(diff.deleted_cogs)} cog(s)")
    reason_str = ", ".join(reasons) if reasons else "code change"

    print_info(f"[Update] Hot Restart  — {reason_str}  ({diff.old_sha[:7]}→{diff.new_sha[:7]})")

    # ── 1. Pull ───────────────────────────────────────────────────────────────
    if not git_pull(repo_path):
        print_err("[Update] git pull failed — aborting restart.")
        return

    # ── 2. Pip install if requirements changed ────────────────────────────────
    if diff.requirements_changed and scan_result is not None:
        print_info("[Update] Installing updated requirements ...")
        _pip_install(scan_result)

    # ── 3. Stop bot ───────────────────────────────────────────────────────────
    if bot.is_running:
        print_info("[Update] Stopping bot ...")
        bot.stop()
        time.sleep(1.5)   # brief pause for port / resource release

    # ── 4. Start bot ──────────────────────────────────────────────────────────
    print_info("[Update] Restarting bot ...")
    started = bot.start()
    if started:
        print_ok("[Update] Bot restarted successfully.")
    else:
        print_err("[Update] Bot failed to restart. Check logs.")


# ── Helpers ───────────────────────────────────────────────────────────────────

def git_pull(repo_path: str) -> bool:
    """
    Run `git pull --ff-only` in the repository.

    Returns True on success.
    """
    try:
        proc = subprocess.run(
            ["git", "pull", "--ff-only"],
            cwd=repo_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=30,
        )
        if proc.returncode == 0:
            log.info("[Git] Pull OK  %s", proc.stdout.strip()[:80])
            return True
        else:
            log.error("[Git] Pull failed  rc=%d  %s", proc.returncode, proc.stderr.strip()[:120])
            return False
    except Exception as exc:
        log.error("[Git] Pull exception: %s", exc)
        return False


def _pip_install(scan_result) -> None:
    """Re-run pip install for the bot's requirements file."""
    try:
        from runtime.process.launcher import install_requirements
        install_requirements(scan_result.raw_requirements)
    except Exception as exc:
        log.warning("[Executor] pip install failed: %s", exc)
        print_warn(f"[Update] pip install failed: {exc}")
