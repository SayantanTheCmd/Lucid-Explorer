"""
runtime/process/manager.py
Launch the Discord bot's main.py as a subprocess.

The bot's stdout and stderr are piped back and forwarded to HIBM's logger
and stdout so they appear in the Pterodactyl console in real time.

The manager also monitors the subprocess exit and updates BotStatus.
"""

import os
import subprocess
import sys
import threading
from typing import Optional

from runtime.constants.enums  import BotStatus
from runtime.utils.logger     import get_logger, print_ok, print_err, print_info

log = get_logger(__name__)


class BotProcess:
    """
    Manages a single running Discord bot subprocess.

    Usage:
        bp = BotProcess(
            "my-bot",
            "/path/to/repo/main.py",
            cmd_override=[sys.executable, "-u", "/path/to/_hibm_launch.py"],
            ipc_port=54321,
        )
        bp.start()
        bp.wait()          # Block until process exits
    """

    def __init__(
        self,
        repo_name:    str,
        main_path:    str,
        cmd_override: list = None,   # if set, used instead of [python, main_path]
        ipc_port:     int  = 0,      # passed to bot as HIBM_IPC_PORT env var
    ):
        self.repo_name    = repo_name
        self.main_path    = main_path
        self.repo_dir     = os.path.dirname(main_path)
        self.cmd_override = cmd_override
        self.ipc_port     = ipc_port
        self.status       = BotStatus.PENDING
        self._proc: Optional[subprocess.Popen] = None
        self._stdout_thread: Optional[threading.Thread] = None
        self._stderr_thread: Optional[threading.Thread] = None
        self.is_restarting = False

    # ── Public API ─────────────────────────────────────────────────────────────
    def start(self) -> bool:
        """
        Launch the bot subprocess.

        Returns:
            True if the process started successfully, False otherwise.
        """
        if self._proc and self._proc.poll() is None:
            log.warning("[%s] Bot is already running (PID %d)", self.repo_name, self._proc.pid)
            return True

        self.status = BotStatus.STARTING
        cmd = self.cmd_override or [sys.executable, "-u", self.main_path]

        # Build environment: inherit parent env + inject HIBM_IPC_PORT + PYTHONPATH
        env = os.environ.copy()
        if self.ipc_port:
            env["HIBM_IPC_PORT"] = str(self.ipc_port)
            
        # Inject preinstalled packages into PYTHONPATH so the bot process can import them
        cache_pkgs = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "..", "cache", "packages")
        )
        if os.path.exists(cache_pkgs):
            old_pp = env.get("PYTHONPATH", "")
            env["PYTHONPATH"] = f"{cache_pkgs}{os.pathsep}{old_pp}" if old_pp else cache_pkgs

        print_info(f"Launching '{self.repo_name}' → {os.path.basename(cmd[-1])}")
        if self.ipc_port:
            print_info(f"IPC port: {self.ipc_port}")
        log.info("[%s] Launching: %s", self.repo_name, cmd)

        try:
            self._proc = subprocess.Popen(
                cmd,
                cwd=self.repo_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,           # Line-buffered
                encoding="utf-8",
                errors="replace",
                env=env,
            )
        except Exception as exc:
            self.status = BotStatus.CRASHED
            print_err(f"Failed to launch '{self.repo_name}': {exc}")
            log.critical("[%s] Launch failed: %s", self.repo_name, exc)
            return False

        self.status = BotStatus.RUNNING
        print_ok(f"'{self.repo_name}' started — PID {self._proc.pid}")
        log.info("[%s] Running with PID %d", self.repo_name, self._proc.pid)

        # Stream stdout / stderr in background threads
        self._stdout_thread = threading.Thread(
            target=self._stream, args=(self._proc.stdout, "OUT"), daemon=True
        )
        self._stderr_thread = threading.Thread(
            target=self._stream, args=(self._proc.stderr, "ERR"), daemon=True
        )
        self._stdout_thread.start()
        self._stderr_thread.start()

        return True

    def wait(self) -> int:
        """Block until the bot subprocess exits. Returns the exit code."""
        if not self._proc:
            return -1
        code = self._proc.wait()
        if self._stdout_thread:
            self._stdout_thread.join(timeout=2)
        if self._stderr_thread:
            self._stderr_thread.join(timeout=2)

        if code == 0:
            self.status = BotStatus.STOPPED
            print_info(f"'{self.repo_name}' exited cleanly (code 0).")
        else:
            self.status = BotStatus.CRASHED
            print_err(f"'{self.repo_name}' crashed with exit code {code}.")
            log.error("[%s] Crashed — exit code %d", self.repo_name, code)

        return code

    def restart(self) -> bool:
        """Gracefully stop then start the bot. Used by hot restart."""
        log.info("[%s] Restarting ...", self.repo_name)
        self.is_restarting = True
        self.stop()
        import time as _time
        _time.sleep(1)
        success = self.start()
        self.is_restarting = False
        return success

    def stop(self) -> None:
        """Gracefully terminate the bot subprocess."""
        if self._proc and self._proc.poll() is None:
            log.info("[%s] Sending SIGTERM to PID %d", self.repo_name, self._proc.pid)
            self._proc.terminate()
            try:
                self._proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                log.warning("[%s] SIGTERM ignored — force killing", self.repo_name)
                self._proc.kill()
            self.status = BotStatus.STOPPED

    @property
    def pid(self) -> Optional[int]:
        return self._proc.pid if self._proc else None

    @property
    def is_running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    # ── Internal ───────────────────────────────────────────────────────────────
    def _stream(self, pipe, tag: str) -> None:
        """Forward subprocess output lines to stdout and logger."""
        prefix = f"  [{self.repo_name}:{tag}]"
        try:
            for line in pipe:
                line = line.rstrip()
                if line:
                    print(f"{prefix} {line}", flush=True)
                    log.debug("%s %s", prefix, line)
        except Exception:
            pass
