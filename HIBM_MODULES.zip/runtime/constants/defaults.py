"""
runtime/constants/defaults.py
Default configuration values and the pre-install package list.
These are the fallback values used when settings.json is absent or incomplete.
"""

# ── Pre-compiled package bundle ─────────────────────────────────────────────────────
# These packages live in unloader/preinstalled.zip and are extracted to
# cache/packages/ at startup by unloader.py.
# The launcher skips pip for anything already present in this list.
# NOTE: uvloop is Linux-only; unloader handles the platform check.
PREINSTALLED_PACKAGES = [
    "discord.py",
    "aiohttp",
    "aiosqlite",
    "python-dotenv",
    "orjson",
    "psutil",
    "watchdog",
    "GitPython",
    "PyYAML",
    "pydantic",
    "rich",
    "colorama",
    "cryptography",
    "tenacity",
    "apscheduler",
    "httpx",
    "aiocache",
    "uvloop",          # Linux/macOS only — skipped on Windows automatically
    "typing_extensions",
    "packaging",
]

# Normalised set for O(1) lookup by the launcher
PREINSTALLED_SET: set[str] = {
    p.lower().replace("-", "_") for p in PREINSTALLED_PACKAGES
}

# Legacy alias — kept so old imports don’t break
BASE_PACKAGES = PREINSTALLED_PACKAGES

# ── pip install settings ──────────────────────────────────────────────────────
PIP_BATCH_SIZE         = 1       # Max concurrent pip installs at one time (reduced from 5 to prevent memory spikes)
PIP_TIMEOUT_SECONDS    = 300     # Per-package install timeout (increased from 120s)
PIP_UPGRADE_BASE       = False   # Whether to --upgrade base packages if already present

# ── Git polling ───────────────────────────────────────────────────────────────
GIT_POLL_INTERVAL      = 5       # Seconds between each git fetch+compare cycle

# ── Process ───────────────────────────────────────────────────────────────────
BOT_RESTART_ON_CRASH   = False   # Phase 2 feature — stub default
MAX_CRASH_RETRIES      = 3

# ── Logging ───────────────────────────────────────────────────────────────────
LOG_LEVEL              = "INFO"
LOG_MAX_BYTES          = 5 * 1024 * 1024   # 5 MB per log file
LOG_BACKUP_COUNT       = 3

# ── Discovery — main file candidates (checked in order) ──────────────────────
MAIN_FILE_CANDIDATES = [
    "main.py",
    "bot.py",
    "run.py",
    "start.py",
    "app.py",
]

# ── Discovery — requirements file candidates (checked in order) ──────────────
REQUIREMENTS_CANDIDATES = [
    "requirements.txt",
    "requirement.txt",
    "Requirements.txt",
    "Requirement.txt",
]

# ── Cog detection patterns ────────────────────────────────────────────────────
# Strings that indicate a Python file is a Discord cog.
COG_PATTERNS = [
    "commands.Cog",
    "app_commands.Group",
    "Cog.listener",
    "async def setup(",      # discord.py v2 setup(bot) convention
]

# ── UI ────────────────────────────────────────────────────────────────────────
BANNER = r"""
  _   _ ___ ___ __  __
 | | | |_ _| _ )  \/  |
 | |_| || || _ \ |\/| |
  \___/|___|___/_|  |_|

  Hit Intelligence Bot Manager
  ─────────────────────────────
"""

VERSION = "1.0.0"
