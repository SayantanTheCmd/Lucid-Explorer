"""
runtime/updater/pull.py
Background git polling engine.

Every N seconds (default: 5) it compares the local HEAD SHA with the
remote HEAD SHA. If they differ, it logs that an update is available.

The actual decision of what to do with that update is deferred to the
decision engine (Phase 2). For now, we just log and notify.

This module runs entirely in a daemon thread so it never blocks the
main bot process.
"""

import subprocess
import threading
import time
from typing import Optional, Callable

from runtime.utils.logger        import get_logger
from runtime.utils.config        import get as get_config
from runtime.updater.commit_tracker import get_stored_sha, store_sha
from runtime.constants.enums     import UpdateStatus

log = get_logger(__name__)


class GitPoller(threading.Thread):
    """
    Daemon thread that polls git every `interval` seconds.

    Usage:
        poller = GitPoller(repo_name="my-bot", repo_path="/path/to/repo")
        poller.start()
        # ... runs forever in background ...
        poller.stop()
    """

    def __init__(
        self,
        repo_name: str,
        repo_path: str,
        interval: Optional[int] = None,
        on_update_available: Optional[Callable[[str, str, str], None]] = None,
    ):
        super().__init__(name=f"git-poller-{repo_name}", daemon=True)
        self.repo_name = repo_name
        self.repo_path = repo_path
        self.interval  = interval or get_config("git_poll_interval", 5)
        self.on_update_available = on_update_available  # callback(repo_name, old_sha, new_sha)
        self._stop_event = threading.Event()

    # ── Public API ─────────────────────────────────────────────────────────────
    def stop(self) -> None:
        """Signal the poller to stop after the current sleep completes."""
        self._stop_event.set()
        log.info("[%s] Git poller stopping", self.repo_name)

    # ── Thread body ────────────────────────────────────────────────────────────
    def run(self) -> None:
        log.info(
            "[%s] Git poller started — interval: %ds",
            self.repo_name, self.interval,
        )
        while not self._stop_event.is_set():
            try:
                status, local_sha, remote_sha = self._poll()
                self._process_status(status, local_sha, remote_sha)
            except Exception as exc:
                log.warning("[%s] Poller error: %s", self.repo_name, exc)

            # Interruptible sleep — checks stop_event every second
            for _ in range(self.interval):
                if self._stop_event.is_set():
                    break
                time.sleep(1)

        log.info("[%s] Git poller exited", self.repo_name)

    # ── Internal ───────────────────────────────────────────────────────────────
    def _poll(self) -> tuple[UpdateStatus, str, str]:
        """
        Check remote using ls-remote (fast). If changed, fetch it.
        Returns: (UpdateStatus, local_sha, remote_sha)
        """
        # 1. Local HEAD
        local_sha = self._get_sha("HEAD")
        if not local_sha:
            return UpdateStatus.ERROR, "", ""

        # 2. Fast remote check (ls-remote doesn't download packfiles)
        ls_remote = self._get_ls_remote_sha()
        if not ls_remote:
            return UpdateStatus.ERROR, local_sha, ""
            
        if local_sha == ls_remote:
            return UpdateStatus.UP_TO_DATE, local_sha, ls_remote
            
        # 3. They differ! Now we actually do the expensive fetch.
        fetch_rc = self._run_git(["git", "fetch", "--quiet", "origin"])
        if fetch_rc != 0:
            return UpdateStatus.ERROR, local_sha, ls_remote

        # 4. Remote HEAD (after fetch, FETCH_HEAD holds the latest)
        remote_sha = self._get_sha("FETCH_HEAD")
        if not remote_sha:
            return UpdateStatus.UNKNOWN, local_sha, ""

        return UpdateStatus.BEHIND, local_sha, remote_sha

    def _process_status(self, status: UpdateStatus, local_sha: str, remote_sha: str) -> None:
        if status == UpdateStatus.UP_TO_DATE:
            log.debug("[%s] Up to date (%s)", self.repo_name, local_sha[:7])

        elif status == UpdateStatus.BEHIND:
            stored = get_stored_sha(self.repo_name)
            # Only log once per new remote SHA
            if stored != remote_sha:
                log.info(
                    "[%s] UPDATE AVAILABLE — local: %s  remote: %s",
                    self.repo_name, local_sha[:7], remote_sha[:7],
                )
                print(
                    f"\n  [GIT] Update available for '{self.repo_name}' "
                    f"({local_sha[:7]} → {remote_sha[:7]})"
                )
                store_sha(self.repo_name, remote_sha)
                if self.on_update_available:
                    self.on_update_available(self.repo_name, local_sha, remote_sha)

        elif status == UpdateStatus.ERROR:
            log.warning("[%s] Git fetch failed — will retry next cycle", self.repo_name)

        elif status == UpdateStatus.UNKNOWN:
            log.debug("[%s] FETCH_HEAD not available yet", self.repo_name)

    def _run_git(self, cmd: list[str]) -> int:
        try:
            proc = subprocess.run(
                cmd,
                cwd=self.repo_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=15,
            )
            return proc.returncode
        except Exception as exc:
            log.debug("[%s] subprocess error: %s", self.repo_name, exc)
            return -1

    def _get_sha(self, ref: str) -> str:
        try:
            proc = subprocess.run(
                ["git", "rev-parse", ref],
                cwd=self.repo_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=10,
            )
            if proc.returncode == 0:
                return proc.stdout.strip()
        except Exception:
            pass
        return ""

    def _get_ls_remote_sha(self) -> str:
        """Lightweight remote check. Only does a TLS handshake, NO packfiles."""
        try:
            proc = subprocess.run(
                ["git", "ls-remote", "origin", "HEAD"],
                cwd=self.repo_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=10,
            )
            if proc.returncode == 0 and proc.stdout:
                # Output looks like: "sha11111111\tHEAD"
                return proc.stdout.split()[0].strip()
        except Exception:
            pass
        return ""


def start_poller(
    repo_name: str,
    repo_path: str,
    interval: Optional[int] = None,
    on_update_available: Optional[Callable] = None,
) -> GitPoller:
    """Convenience factory: create, start, and return a GitPoller."""
    poller = GitPoller(
        repo_name=repo_name,
        repo_path=repo_path,
        interval=interval,
        on_update_available=on_update_available,
    )
    poller.start()
    return poller
